<?php
require_once 'config.php';
require_once 'layout.php';
$S = get_settings($con);
brand_head($S, 'Student admission'); ?>
<body>
<div class="auth-wrap" style="align-items:flex-start;padding-top:2.5rem">
  <div style="width:100%;max-width:760px;position:relative;z-index:1">
    <div class="auth-logo"><img src="logo.png" alt="logo"><span class="t"><?= htmlspecialchars($S['college_name']) ?></span><span class="s"><?= htmlspecialchars($S['college_location']) ?> &middot; <?= htmlspecialchars($S['tagline']) ?></span></div>
    <div id="app"></div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/app.js"></script>
<script>
const app = $('#app');
const LABEL = <?= json_encode($S['student_id_label']) ?>, WELCOME = <?= json_encode($S['student_welcome']) ?>;
function loginView() {
  app.html(`<div class="card mx-auto" style="max-width:420px"><div class="card-body p-4">
    <h5 class="mb-1">Welcome 👋</h5><p class="mb-4">${esc(WELCOME)}</p>
    <label class="form-label">${esc(LABEL)}</label>
    <input id="ref" type="text" inputmode="text" autocomplete="off" class="form-control mb-4" placeholder="${esc(LABEL)}" autofocus>
    <button id="go" class="btn btn-primary w-100">Continue</button></div></div>`);
  const go = () => api({student_login: true, reference_no: $('#ref').val()}).then(r => view(r.view));
  $('#go').on('click', go); $('#ref').on('keydown', e => { if (e.key === 'Enter') go(); });
}
const header = v => `<div class="card mb-4"><div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-2"><div class="d-flex gap-3 align-items-center"><span class="avatar-init bg-label-primary"><i class="bx bx-id-card"></i></span><div><h5 class="mb-0">${esc(v.reference_no)}</h5><small class="text-muted">Academic year ${esc(v.year)}</small></div></div><div>${badge(v.status)} <button id="out" class="btn btn-sm btn-outline-secondary ms-2">Log out</button></div></div></div>`;
function input(f) {
  const req = f.required ? 'required' : '', val = esc(f.value || '');
  const lbl = `<label class="form-label">${esc(f.label)}${f.required ? ' <span class="text-danger">*</span>' : ''}</label>`;
  if (!f.editable) return `<div class="col-md-6"><div class="card h-100" style="background:#fafafc"><div class="card-body"><small class="text-muted d-block mb-1">${esc(f.label)}</small><div>${f.value ? (f.type === 'file' ? 'Uploaded' : val) : 'Not provided'}</div></div></div></div>`;
  if (f.type === 'select') return `<div class="col-md-6">${lbl}<select class="form-select fv" data-id="${f.id}" ${req}><option value="">Select...</option>${(f.options || []).map(o => `<option ${o === f.value ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></div>`;
  if (f.type === 'textarea') return `<div class="col-12">${lbl}<textarea class="form-control fv" data-id="${f.id}" ${req}>${val}</textarea></div>`;
  if (f.type === 'file') return `<div class="col-md-6">${lbl}<input type="file" class="form-control ff" data-id="${f.id}" accept=".jpg,.jpeg,.png,.pdf">${f.value ? '<small class="text-muted">Already uploaded. Choose a new file to replace it.</small>' : ''}</div>`;
  return `<div class="col-md-6">${lbl}<input type="${f.type}" class="form-control fv" data-id="${f.id}" value="${val}" ${req}></div>`;
}
function view(v) {
  if (!v) return loginView();
  let h = header(v);
  if (v.status === 'approved') h += `<div class="alert alert-success"><i class="bx bx-check-circle"></i> Congratulations! Your admission has been approved.</div>`;
  if (v.status === 'rejected') h += `<div class="alert alert-danger"><strong>Your submission needs changes.</strong><br>${esc(v.reject_reason || '')}</div>`;
  if (v.status === 'submitted' && !v.can_edit) h += `<div class="alert alert-warning">Your details are submitted and awaiting review.</div>`;
  if (v.can_edit) {
    h += (v.status === 'submitted' ? '<div class="alert alert-info">You can still update the details that are open for editing.</div>' : '') +
      `<div class="card"><div class="card-body"><div class="row g-3">${v.fields.map(input).join('') || 'No details are being requested yet. Please check back soon.'}</div>
      ${v.fields.length ? `<button id="save" class="btn btn-primary mt-4">${v.status === 'pending' ? 'Submit details' : 'Save changes'}</button>` : ''}</div></div>`;
  } else h += `<div class="row g-3">${detailCards(v.fields)}</div>`;
  app.html(h);
}
$(document).on('click', '#out', () => api({student_logout: true}).then(loginView));
$(document).on('click', '#save', async function () {
  const values = {}, files = {};
  $('.fv').each(function () { values[$(this).data('id')] = $(this).val(); });
  for (const el of $('.ff').get()) { const f = el.files[0]; if (f) files[$(el).data('id')] = {name: f.name, data: await fileToB64(f)}; }
  api({student_submit: true, values: JSON.stringify(values), files: JSON.stringify(files)}).then(r => { view(r.view); toast('Details saved'); window.scrollTo(0, 0); });
});
api({student_session: true}).then(r => view(r.view));
</script></body></html>