-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 07, 2026 at 06:02 AM
-- Server version: 10.11.15-MariaDB-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sedacoe_admission`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_years`
--

CREATE TABLE `academic_years` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `open_registration` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_years`
--

INSERT INTO `academic_years` (`id`, `name`, `status`, `open_registration`, `created_at`) VALUES
(1, '2026/27', 'open', 0, '2026-10-07 09:26:56');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('super','admin') NOT NULL DEFAULT 'admin',
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `full_name`, `username`, `password_hash`, `role`, `is_active`) VALUES
(2, 'accounts', 'accounts', '$2y$10$96LgFUYSeAMNztEeAcOWPOXs3VlV5BsVsq878s.Tx37x8KcTm0rgO', 'admin', 1),
(3, 'IT Support', 'it.support', '$2y$12$lakjkllzWmPKF2sPJcBGsusYwqMyWqo4JArgoVsRK651j3w5vRVAe', 'super', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admitted_students`
--

CREATE TABLE `admitted_students` (
  `id` int(11) NOT NULL,
  `year_id` int(11) NOT NULL,
  `reference_no` varchar(60) NOT NULL,
  `status` enum('pending','submitted','approved','rejected') NOT NULL DEFAULT 'pending',
  `reject_reason` varchar(500) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admitted_students`
--

INSERT INTO `admitted_students` (`id`, `year_id`, `reference_no`, `status`, `reject_reason`, `submitted_at`, `decided_at`) VALUES
(3, 1, '2653005', 'pending', NULL, NULL, NULL),
(4, 1, '2638933', 'pending', NULL, NULL, NULL),
(5, 1, '2609034', 'pending', NULL, NULL, NULL),
(6, 1, '2646634', 'pending', NULL, NULL, NULL),
(7, 1, '2604223', 'pending', NULL, NULL, NULL),
(8, 1, '2611183', 'pending', NULL, NULL, NULL),
(9, 1, '2617414', 'pending', NULL, NULL, NULL),
(10, 1, '2643040', 'pending', NULL, NULL, NULL),
(11, 1, '2628879', 'pending', NULL, NULL, NULL),
(12, 1, '2644151', 'pending', NULL, NULL, NULL),
(13, 1, '2651106', 'pending', NULL, NULL, NULL),
(14, 1, '2650720', 'pending', NULL, NULL, NULL),
(15, 1, '2653922', 'pending', NULL, NULL, NULL),
(16, 1, '2653554', 'pending', NULL, NULL, NULL),
(17, 1, '2650696', 'pending', NULL, NULL, NULL),
(18, 1, '2644762', 'pending', NULL, NULL, NULL),
(19, 1, '2603819', 'pending', NULL, NULL, NULL),
(20, 1, '2640857', 'pending', NULL, NULL, NULL),
(21, 1, '2605924', 'pending', NULL, NULL, NULL),
(22, 1, '2628583', 'pending', NULL, NULL, NULL),
(23, 1, '2629406', 'pending', NULL, NULL, NULL),
(24, 1, '2654705', 'pending', NULL, NULL, NULL),
(25, 1, '2654173', 'pending', NULL, NULL, NULL),
(26, 1, '2654185', 'pending', NULL, NULL, NULL),
(27, 1, '2606579', 'pending', NULL, NULL, NULL),
(28, 1, '2645421', 'pending', NULL, NULL, NULL),
(29, 1, '2647679', 'pending', NULL, NULL, NULL),
(30, 1, '2636566', 'pending', NULL, NULL, NULL),
(31, 1, '2636126', 'pending', NULL, NULL, NULL),
(32, 1, '2625616', 'pending', NULL, NULL, NULL),
(33, 1, '2650549', 'pending', NULL, NULL, NULL),
(34, 1, '2615970', 'pending', NULL, NULL, NULL),
(35, 1, '2626273', 'pending', NULL, NULL, NULL),
(36, 1, '2615797', 'pending', NULL, NULL, NULL),
(37, 1, '2629151', 'pending', NULL, NULL, NULL),
(38, 1, '2630099', 'pending', NULL, NULL, NULL),
(39, 1, '2609575', 'pending', NULL, NULL, NULL),
(40, 1, '2624123', 'pending', NULL, NULL, NULL),
(41, 1, '2624073', 'pending', NULL, NULL, NULL),
(42, 1, '2624884', 'pending', NULL, NULL, NULL),
(43, 1, '2624910', 'pending', NULL, NULL, NULL),
(44, 1, '2623106', 'pending', NULL, NULL, NULL),
(45, 1, '2636044', 'pending', NULL, NULL, NULL),
(46, 1, '2605894', 'pending', NULL, NULL, NULL),
(47, 1, '2650567', 'pending', NULL, NULL, NULL),
(48, 1, '2609148', 'pending', NULL, NULL, NULL),
(49, 1, '2631667', 'pending', NULL, NULL, NULL),
(50, 1, '2640068', 'pending', NULL, NULL, NULL),
(51, 1, '2604868', 'pending', NULL, NULL, NULL),
(52, 1, '2611422', 'pending', NULL, NULL, NULL),
(53, 1, '2620505', 'pending', NULL, NULL, NULL),
(54, 1, '2616396', 'pending', NULL, NULL, NULL),
(55, 1, '2628402', 'pending', NULL, NULL, NULL),
(56, 1, '2652548', 'pending', NULL, NULL, NULL),
(57, 1, '2609591', 'pending', NULL, NULL, NULL),
(58, 1, '2604577', 'pending', NULL, NULL, NULL),
(59, 1, '2625315', 'pending', NULL, NULL, NULL),
(60, 1, '2649779', 'pending', NULL, NULL, NULL),
(61, 1, '2600403', 'pending', NULL, NULL, NULL),
(62, 1, '2630713', 'pending', NULL, NULL, NULL),
(63, 1, '2608596', 'pending', NULL, NULL, NULL),
(64, 1, '2655932', 'pending', NULL, NULL, NULL),
(65, 1, '2610343', 'pending', NULL, NULL, NULL),
(66, 1, '2619526', 'pending', NULL, NULL, NULL),
(67, 1, '2649110', 'pending', NULL, NULL, NULL),
(68, 1, '2630866', 'pending', NULL, NULL, NULL),
(69, 1, '2601803', 'pending', NULL, NULL, NULL),
(70, 1, '2618863', 'pending', NULL, NULL, NULL),
(71, 1, '2644079', 'pending', NULL, NULL, NULL),
(72, 1, '2621084', 'pending', NULL, NULL, NULL),
(73, 1, '2612422', 'pending', NULL, NULL, NULL),
(74, 1, '2619739', 'pending', NULL, NULL, NULL),
(75, 1, '2626257', 'pending', NULL, NULL, NULL),
(76, 1, '2631210', 'pending', NULL, NULL, NULL),
(77, 1, '2637122', 'pending', NULL, NULL, NULL),
(78, 1, '2648852', 'pending', NULL, NULL, NULL),
(79, 1, '2644458', 'pending', NULL, NULL, NULL),
(80, 1, '2622137', 'pending', NULL, NULL, NULL),
(81, 1, '2615402', 'pending', NULL, NULL, NULL),
(82, 1, '2623518', 'pending', NULL, NULL, NULL),
(83, 1, '2625383', 'pending', NULL, NULL, NULL),
(84, 1, '2604985', 'pending', NULL, NULL, NULL),
(85, 1, '2606848', 'pending', NULL, NULL, NULL),
(86, 1, '2616278', 'pending', NULL, NULL, NULL),
(87, 1, '2616815', 'pending', NULL, NULL, NULL),
(88, 1, '2609319', 'pending', NULL, NULL, NULL),
(89, 1, '2638094', 'pending', NULL, NULL, NULL),
(90, 1, '2644614', 'pending', NULL, NULL, NULL),
(91, 1, '2614095', 'pending', NULL, NULL, NULL),
(92, 1, '2627169', 'pending', NULL, NULL, NULL),
(93, 1, '2611157', 'pending', NULL, NULL, NULL),
(94, 1, '2616110', 'pending', NULL, NULL, NULL),
(95, 1, '2601554', 'pending', NULL, NULL, NULL),
(96, 1, '2646596', 'pending', NULL, NULL, NULL),
(97, 1, '2606590', 'pending', NULL, NULL, NULL),
(98, 1, '2611660', 'pending', NULL, NULL, NULL),
(99, 1, '2632115', 'pending', NULL, NULL, NULL),
(100, 1, '2610187', 'pending', NULL, NULL, NULL),
(101, 1, '2619795', 'pending', NULL, NULL, NULL),
(102, 1, '2605938', 'pending', NULL, NULL, NULL),
(103, 1, '2615345', 'pending', NULL, NULL, NULL),
(104, 1, '2610562', 'pending', NULL, NULL, NULL),
(105, 1, '2611713', 'pending', NULL, NULL, NULL),
(106, 1, '2617865', 'pending', NULL, NULL, NULL),
(107, 1, '2638162', 'pending', NULL, NULL, NULL),
(108, 1, '2652264', 'pending', NULL, NULL, NULL),
(109, 1, '2640568', 'pending', NULL, NULL, NULL),
(110, 1, '2605676', 'pending', NULL, NULL, NULL),
(111, 1, '2620566', 'pending', NULL, NULL, NULL),
(112, 1, '2631533', 'pending', NULL, NULL, NULL),
(113, 1, '2631800', 'pending', NULL, NULL, NULL),
(114, 1, '2625281', 'pending', NULL, NULL, NULL),
(115, 1, '2638607', 'pending', NULL, NULL, NULL),
(116, 1, '2641957', 'pending', NULL, NULL, NULL),
(117, 1, '2620711', 'pending', NULL, NULL, NULL),
(118, 1, '2626530', 'pending', NULL, NULL, NULL),
(119, 1, '2625611', 'pending', NULL, NULL, NULL),
(120, 1, '2639591', 'pending', NULL, NULL, NULL),
(121, 1, '2612977', 'pending', NULL, NULL, NULL),
(122, 1, '2619048', 'pending', NULL, NULL, NULL),
(123, 1, '2643891', 'pending', NULL, NULL, NULL),
(124, 1, '2611074', 'pending', NULL, NULL, NULL),
(125, 1, '2611916', 'pending', NULL, NULL, NULL),
(126, 1, '2609932', 'pending', NULL, NULL, NULL),
(127, 1, '2609414', 'pending', NULL, NULL, NULL),
(128, 1, '2615680', 'pending', NULL, NULL, NULL),
(129, 1, '2642383', 'pending', NULL, NULL, NULL),
(130, 1, '2630315', 'pending', NULL, NULL, NULL),
(131, 1, '2636642', 'pending', NULL, NULL, NULL),
(132, 1, '2629440', 'pending', NULL, NULL, NULL),
(133, 1, '2604291', 'pending', NULL, NULL, NULL),
(134, 1, '2609686', 'pending', NULL, NULL, NULL),
(135, 1, '2606076', 'pending', NULL, NULL, NULL),
(136, 1, '2605926', 'pending', NULL, NULL, NULL),
(137, 1, '2601429', 'pending', NULL, NULL, NULL),
(138, 1, '2600061', 'pending', NULL, NULL, NULL),
(139, 1, '2621743', 'pending', NULL, NULL, NULL),
(140, 1, '2629404', 'pending', NULL, NULL, NULL),
(141, 1, '2624180', 'pending', NULL, NULL, NULL),
(142, 1, '2641131', 'pending', NULL, NULL, NULL),
(143, 1, '2642713', 'pending', NULL, NULL, NULL),
(144, 1, '2637428', 'pending', NULL, NULL, NULL),
(145, 1, '2633592', 'pending', NULL, NULL, NULL),
(146, 1, '2637960', 'pending', NULL, NULL, NULL),
(147, 1, '2649047', 'pending', NULL, NULL, NULL),
(148, 1, '2628854', 'pending', NULL, NULL, NULL),
(149, 1, '2637616', 'pending', NULL, NULL, NULL),
(150, 1, '2618243', 'pending', NULL, NULL, NULL),
(151, 1, '2613685', 'pending', NULL, NULL, NULL),
(152, 1, '2627101', 'pending', NULL, NULL, NULL),
(153, 1, '2625704', 'pending', NULL, NULL, NULL),
(154, 1, '2613323', 'pending', NULL, NULL, NULL),
(155, 1, '2654102', 'pending', NULL, NULL, NULL),
(156, 1, '2623403', 'pending', NULL, NULL, NULL),
(157, 1, '2649734', 'pending', NULL, NULL, NULL),
(158, 1, '2637157', 'pending', NULL, NULL, NULL),
(159, 1, '2624517', 'pending', NULL, NULL, NULL),
(160, 1, '2616095', 'pending', NULL, NULL, NULL),
(161, 1, '2602727', 'pending', NULL, NULL, NULL),
(162, 1, '2608402', 'pending', NULL, NULL, NULL),
(163, 1, '2624279', 'pending', NULL, NULL, NULL),
(164, 1, '2636138', 'pending', NULL, NULL, NULL),
(165, 1, '2605605', 'pending', NULL, NULL, NULL),
(166, 1, '2651960', 'pending', NULL, NULL, NULL),
(167, 1, '2638079', 'pending', NULL, NULL, NULL),
(168, 1, '2639561', 'pending', NULL, NULL, NULL),
(169, 1, '2652107', 'pending', NULL, NULL, NULL),
(170, 1, '2649996', 'pending', NULL, NULL, NULL),
(171, 1, '2636822', 'pending', NULL, NULL, NULL),
(172, 1, '2625768', 'pending', NULL, NULL, NULL),
(173, 1, '2643876', 'pending', NULL, NULL, NULL),
(174, 1, '2644944', 'pending', NULL, NULL, NULL),
(175, 1, '2637859', 'pending', NULL, NULL, NULL),
(176, 1, '2609304', 'pending', NULL, NULL, NULL),
(177, 1, '2628611', 'pending', NULL, NULL, NULL),
(178, 1, '2620116', 'pending', NULL, NULL, NULL),
(179, 1, '2639569', 'pending', NULL, NULL, NULL),
(180, 1, '2636456', 'pending', NULL, NULL, NULL),
(181, 1, '2652184', 'pending', NULL, NULL, NULL),
(182, 1, '2619675', 'pending', NULL, NULL, NULL),
(183, 1, '2624081', 'pending', NULL, NULL, NULL),
(184, 1, '2620720', 'pending', NULL, NULL, NULL),
(185, 1, '2612701', 'pending', NULL, NULL, NULL),
(186, 1, '2637593', 'pending', NULL, NULL, NULL),
(187, 1, '2619171', 'pending', NULL, NULL, NULL),
(188, 1, '2632978', 'pending', NULL, NULL, NULL),
(189, 1, '2636274', 'pending', NULL, NULL, NULL),
(190, 1, '2650172', 'pending', NULL, NULL, NULL),
(191, 1, '2645147', 'pending', NULL, NULL, NULL),
(192, 1, '2607428', 'pending', NULL, NULL, NULL),
(193, 1, '2609829', 'pending', NULL, NULL, NULL),
(194, 1, '2653918', 'pending', NULL, NULL, NULL),
(195, 1, '2625263', 'pending', NULL, NULL, NULL),
(196, 1, '2613046', 'pending', NULL, NULL, NULL),
(197, 1, '2615765', 'pending', NULL, NULL, NULL),
(198, 1, '2648145', 'pending', NULL, NULL, NULL),
(199, 1, '2607738', 'pending', NULL, NULL, NULL),
(200, 1, '2644915', 'pending', NULL, NULL, NULL),
(201, 1, '2633711', 'pending', NULL, NULL, NULL),
(202, 1, '2647861', 'pending', NULL, NULL, NULL),
(203, 1, '2614282', 'pending', NULL, NULL, NULL),
(204, 1, '2610468', 'pending', NULL, NULL, NULL),
(205, 1, '2651032', 'pending', NULL, NULL, NULL),
(206, 1, '2633763', 'pending', NULL, NULL, NULL),
(207, 1, '2620731', 'pending', NULL, NULL, NULL),
(208, 1, '2611922', 'pending', NULL, NULL, NULL),
(209, 1, '2628984', 'pending', NULL, NULL, NULL),
(210, 1, '2644063', 'pending', NULL, NULL, NULL),
(211, 1, '2636317', 'pending', NULL, NULL, NULL),
(212, 1, '2610783', 'pending', NULL, NULL, NULL),
(213, 1, '2652983', 'pending', NULL, NULL, NULL),
(214, 1, '2623060', 'pending', NULL, NULL, NULL),
(215, 1, '2607020', 'pending', NULL, NULL, NULL),
(216, 1, '2655426', 'pending', NULL, NULL, NULL),
(217, 1, '2640895', 'pending', NULL, NULL, NULL),
(218, 1, '2628120', 'pending', NULL, NULL, NULL),
(219, 1, '2608646', 'pending', NULL, NULL, NULL),
(220, 1, '2629631', 'pending', NULL, NULL, NULL),
(221, 1, '2616709', 'pending', NULL, NULL, NULL),
(222, 1, '2655154', 'pending', NULL, NULL, NULL),
(223, 1, '2603952', 'pending', NULL, NULL, NULL),
(224, 1, '2603421', 'pending', NULL, NULL, NULL),
(225, 1, '2601585', 'pending', NULL, NULL, NULL),
(226, 1, '2639222', 'pending', NULL, NULL, NULL),
(227, 1, '2601638', 'pending', NULL, NULL, NULL),
(228, 1, '2603913', 'pending', NULL, NULL, NULL),
(229, 1, '2639762', 'pending', NULL, NULL, NULL),
(230, 1, '2643402', 'pending', NULL, NULL, NULL),
(231, 1, '2612008', 'pending', NULL, NULL, NULL),
(232, 1, '2640065', 'pending', NULL, NULL, NULL),
(233, 1, '2619487', 'pending', NULL, NULL, NULL),
(234, 1, '2603657', 'pending', NULL, NULL, NULL),
(235, 1, '2616594', 'pending', NULL, NULL, NULL),
(236, 1, '2627964', 'pending', NULL, NULL, NULL),
(237, 1, '2654473', 'pending', NULL, NULL, NULL),
(238, 1, '2624965', 'pending', NULL, NULL, NULL),
(239, 1, '2635560', 'pending', NULL, NULL, NULL),
(240, 1, '2624438', 'pending', NULL, NULL, NULL),
(241, 1, '2609397', 'pending', NULL, NULL, NULL),
(242, 1, '2630758', 'pending', NULL, NULL, NULL),
(243, 1, '2603727', 'pending', NULL, NULL, NULL),
(244, 1, '2607464', 'pending', NULL, NULL, NULL),
(245, 1, '2611986', 'pending', NULL, NULL, NULL),
(246, 1, '2606026', 'pending', NULL, NULL, NULL),
(247, 1, '2640031', 'pending', NULL, NULL, NULL),
(248, 1, '2605760', 'pending', NULL, NULL, NULL),
(249, 1, '2638703', 'pending', NULL, NULL, NULL),
(250, 1, '2632782', 'pending', NULL, NULL, NULL),
(251, 1, '2618066', 'pending', NULL, NULL, NULL),
(252, 1, '2610465', 'pending', NULL, NULL, NULL),
(253, 1, '2612986', 'pending', NULL, NULL, NULL),
(254, 1, '2627337', 'pending', NULL, NULL, NULL),
(255, 1, '2606115', 'pending', NULL, NULL, NULL),
(256, 1, '2651243', 'pending', NULL, NULL, NULL),
(257, 1, '2632262', 'pending', NULL, NULL, NULL),
(258, 1, '2630939', 'pending', NULL, NULL, NULL),
(259, 1, '2606932', 'pending', NULL, NULL, NULL),
(260, 1, '2654217', 'pending', NULL, NULL, NULL),
(261, 1, '2639873', 'pending', NULL, NULL, NULL),
(262, 1, '2605079', 'pending', NULL, NULL, NULL),
(263, 1, '2625582', 'pending', NULL, NULL, NULL),
(264, 1, '2616408', 'pending', NULL, NULL, NULL),
(265, 1, '2632641', 'pending', NULL, NULL, NULL),
(266, 1, '2610577', 'pending', NULL, NULL, NULL),
(267, 1, '2608382', 'pending', NULL, NULL, NULL),
(268, 1, '2622710', 'pending', NULL, NULL, NULL),
(269, 1, '2637638', 'pending', NULL, NULL, NULL),
(270, 1, '2605952', 'pending', NULL, NULL, NULL),
(271, 1, '2624116', 'pending', NULL, NULL, NULL),
(272, 1, '2643859', 'pending', NULL, NULL, NULL),
(273, 1, '2641260', 'pending', NULL, NULL, NULL),
(274, 1, '2637903', 'pending', NULL, NULL, NULL),
(275, 1, '2602392', 'pending', NULL, NULL, NULL),
(276, 1, '2622841', 'pending', NULL, NULL, NULL),
(277, 1, '2606978', 'pending', NULL, NULL, NULL),
(278, 1, '2632981', 'pending', NULL, NULL, NULL),
(279, 1, '2607780', 'pending', NULL, NULL, NULL),
(280, 1, '2631582', 'pending', NULL, NULL, NULL),
(281, 1, '2649068', 'pending', NULL, NULL, NULL),
(282, 1, '2608578', 'pending', NULL, NULL, NULL),
(283, 1, '2639528', 'pending', NULL, NULL, NULL),
(284, 1, '2616413', 'pending', NULL, NULL, NULL),
(285, 1, '2648583', 'pending', NULL, NULL, NULL),
(286, 1, '2611262', 'pending', NULL, NULL, NULL),
(287, 1, '2609820', 'pending', NULL, NULL, NULL),
(288, 1, '2643467', 'pending', NULL, NULL, NULL),
(289, 1, '2613681', 'pending', NULL, NULL, NULL),
(290, 1, '2617235', 'pending', NULL, NULL, NULL),
(291, 1, '2624870', 'pending', NULL, NULL, NULL),
(292, 1, '2610385', 'pending', NULL, NULL, NULL),
(293, 1, '2632664', 'pending', NULL, NULL, NULL),
(294, 1, '2649445', 'pending', NULL, NULL, NULL),
(295, 1, '2644145', 'pending', NULL, NULL, NULL),
(296, 1, '2620326', 'pending', NULL, NULL, NULL),
(297, 1, '2636853', 'pending', NULL, NULL, NULL),
(298, 1, '2612594', 'pending', NULL, NULL, NULL),
(299, 1, '2605381', 'pending', NULL, NULL, NULL),
(300, 1, '2655418', 'pending', NULL, NULL, NULL),
(301, 1, '2623305', 'pending', NULL, NULL, NULL),
(302, 1, '2616119', 'pending', NULL, NULL, NULL),
(303, 1, '2624381', 'pending', NULL, NULL, NULL),
(304, 1, '2628041', 'pending', NULL, NULL, NULL),
(305, 1, '2644276', 'pending', NULL, NULL, NULL),
(306, 1, '2655809', 'pending', NULL, NULL, NULL),
(307, 1, '2613402', 'pending', NULL, NULL, NULL),
(308, 1, '2613578', 'pending', NULL, NULL, NULL),
(309, 1, '2619490', 'pending', NULL, NULL, NULL),
(310, 1, '2619398', 'pending', NULL, NULL, NULL),
(311, 1, '2600413', 'pending', NULL, NULL, NULL),
(312, 1, '2630869', 'pending', NULL, NULL, NULL),
(313, 1, '2647724', 'pending', NULL, NULL, NULL),
(314, 1, '2643269', 'pending', NULL, NULL, NULL),
(315, 1, '2655985', 'pending', NULL, NULL, NULL),
(316, 1, '2610960', 'pending', NULL, NULL, NULL),
(317, 1, '2642355', 'pending', NULL, NULL, NULL),
(318, 1, '2600160', 'pending', NULL, NULL, NULL),
(319, 1, '2639924', 'pending', NULL, NULL, NULL),
(320, 1, '2612142', 'pending', NULL, NULL, NULL),
(321, 1, '2633317', 'pending', NULL, NULL, NULL),
(322, 1, '2624725', 'pending', NULL, NULL, NULL),
(323, 1, '2604383', 'pending', NULL, NULL, NULL),
(324, 1, '2624447', 'pending', NULL, NULL, NULL),
(325, 1, '2643165', 'pending', NULL, NULL, NULL),
(326, 1, '2652046', 'pending', NULL, NULL, NULL),
(327, 1, '2615995', 'pending', NULL, NULL, NULL),
(328, 1, '2622916', 'pending', NULL, NULL, NULL),
(329, 1, '2605060', 'pending', NULL, NULL, NULL),
(330, 1, '2604630', 'pending', NULL, NULL, NULL),
(331, 1, '2617074', 'pending', NULL, NULL, NULL),
(332, 1, '2632737', 'pending', NULL, NULL, NULL),
(333, 1, '2643726', 'pending', NULL, NULL, NULL),
(334, 1, '2630134', 'pending', NULL, NULL, NULL),
(335, 1, '2621477', 'pending', NULL, NULL, NULL),
(336, 1, '2632965', 'pending', NULL, NULL, NULL),
(337, 1, '2636864', 'pending', NULL, NULL, NULL),
(338, 1, '2624834', 'pending', NULL, NULL, NULL),
(339, 1, '2612849', 'pending', NULL, NULL, NULL),
(340, 1, '2618694', 'pending', NULL, NULL, NULL),
(341, 1, '2604017', 'pending', NULL, NULL, NULL),
(342, 1, '2630029', 'pending', NULL, NULL, NULL),
(343, 1, '2628081', 'pending', NULL, NULL, NULL),
(344, 1, '2623986', 'pending', NULL, NULL, NULL),
(345, 1, '2611941', 'pending', NULL, NULL, NULL),
(346, 1, '2630498', 'pending', NULL, NULL, NULL),
(347, 1, '2621789', 'pending', NULL, NULL, NULL),
(348, 1, '2647973', 'pending', NULL, NULL, NULL),
(349, 1, '2652366', 'pending', NULL, NULL, NULL),
(350, 1, '2653479', 'pending', NULL, NULL, NULL),
(351, 1, '2620441', 'pending', NULL, NULL, NULL),
(352, 1, '2626166', 'pending', NULL, NULL, NULL),
(353, 1, '2625595', 'pending', NULL, NULL, NULL),
(354, 1, '2631676', 'pending', NULL, NULL, NULL),
(355, 1, '2602580', 'pending', NULL, NULL, NULL),
(356, 1, '2631246', 'pending', NULL, NULL, NULL),
(357, 1, '2625506', 'pending', NULL, NULL, NULL),
(358, 1, '2603578', 'pending', NULL, NULL, NULL),
(359, 1, '2632325', 'pending', NULL, NULL, NULL),
(360, 1, '2602935', 'pending', NULL, NULL, NULL),
(361, 1, '2607140', 'pending', NULL, NULL, NULL),
(362, 1, '2652367', 'pending', NULL, NULL, NULL),
(363, 1, '2612251', 'pending', NULL, NULL, NULL),
(364, 1, '2637437', 'pending', NULL, NULL, NULL),
(365, 1, '2628983', 'pending', NULL, NULL, NULL),
(366, 1, '2611514', 'pending', NULL, NULL, NULL),
(367, 1, '2608612', 'pending', NULL, NULL, NULL),
(368, 1, '2622068', 'pending', NULL, NULL, NULL),
(369, 1, '2625248', 'pending', NULL, NULL, NULL),
(370, 1, '2626981', 'pending', NULL, NULL, NULL),
(371, 1, '2655374', 'pending', NULL, NULL, NULL),
(372, 1, '2654290', 'pending', NULL, NULL, NULL),
(373, 1, '2608349', 'pending', NULL, NULL, NULL),
(374, 1, '2619196', 'pending', NULL, NULL, NULL),
(375, 1, '2603099', 'pending', NULL, NULL, NULL),
(376, 1, '2629013', 'pending', NULL, NULL, NULL),
(377, 1, '2608667', 'pending', NULL, NULL, NULL),
(378, 1, '2602956', 'pending', NULL, NULL, NULL),
(379, 1, '2649390', 'pending', NULL, NULL, NULL),
(380, 1, '2630499', 'pending', NULL, NULL, NULL),
(381, 1, '2649436', 'pending', NULL, NULL, NULL),
(382, 1, '2615894', 'pending', NULL, NULL, NULL),
(383, 1, '2600015', 'pending', NULL, NULL, NULL),
(384, 1, '2644881', 'pending', NULL, NULL, NULL),
(385, 1, '2643120', 'pending', NULL, NULL, NULL),
(386, 1, '2620805', 'pending', NULL, NULL, NULL),
(387, 1, '2630900', 'pending', NULL, NULL, NULL),
(388, 1, '2607396', 'pending', NULL, NULL, NULL),
(389, 1, '2603726', 'pending', NULL, NULL, NULL),
(390, 1, '2638212', 'pending', NULL, NULL, NULL),
(391, 1, '2648430', 'pending', NULL, NULL, NULL),
(392, 1, '2616872', 'pending', NULL, NULL, NULL),
(393, 1, '2624049', 'pending', NULL, NULL, NULL),
(394, 1, '2603004', 'pending', NULL, NULL, NULL),
(395, 1, '2629622', 'pending', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `skey` varchar(60) NOT NULL,
  `svalue` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`skey`, `svalue`) VALUES
('college_location', 'Asokore, Koforidua'),
('college_name', 'SDA College of Education'),
('dark_sidebar', '0'),
('primary_color', '#696cff'),
('student_id_label', 'Admission number'),
('student_welcome', 'Enter your admission number to check or complete your admission.'),
('tagline', 'Online Admission Portal');

-- --------------------------------------------------------

--
-- Table structure for table `student_values`
--

CREATE TABLE `student_values` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `year_fields`
--

CREATE TABLE `year_fields` (
  `id` int(11) NOT NULL,
  `year_id` int(11) NOT NULL,
  `label` varchar(80) NOT NULL,
  `type` enum('text','textarea','email','tel','date','number','file','select') NOT NULL DEFAULT 'text',
  `options` text DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 1,
  `allow_update` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `year_fields`
--

INSERT INTO `year_fields` (`id`, `year_id`, `label`, `type`, `options`, `is_required`, `allow_update`, `sort_order`) VALUES
(1, 1, 'Lastname', 'text', NULL, 1, 1, 1),
(2, 1, 'Firstname', 'text', NULL, 1, 1, 2),
(3, 1, 'Other names', 'text', NULL, 1, 1, 3),
(4, 1, 'Date of Birth', 'date', NULL, 1, 1, 4),
(6, 1, 'Ghana Card Number', 'text', NULL, 1, 1, 7),
(7, 1, 'NHIS Number', 'text', NULL, 1, 1, 8),
(11, 1, 'Email Address', 'email', NULL, 1, 1, 9),
(12, 1, 'Telephone Number', 'tel', NULL, 1, 1, 5),
(14, 1, 'Programme on your admmission letter', 'select', '[\"B.Ed Junior High School Education\",\"B.Ed Primary Education\",\"B.Ed Early Grade Education\"]', 1, 1, 10),
(15, 1, 'Whatsapp Number', 'text', NULL, 1, 1, 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_years`
--
ALTER TABLE `academic_years`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `admitted_students`
--
ALTER TABLE `admitted_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_year_ref` (`year_id`,`reference_no`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`skey`);

--
-- Indexes for table `student_values`
--
ALTER TABLE `student_values`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_student_field` (`student_id`,`field_id`),
  ADD KEY `field_id` (`field_id`);

--
-- Indexes for table `year_fields`
--
ALTER TABLE `year_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `year_id` (`year_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_years`
--
ALTER TABLE `academic_years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admitted_students`
--
ALTER TABLE `admitted_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=397;

--
-- AUTO_INCREMENT for table `student_values`
--
ALTER TABLE `student_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `year_fields`
--
ALTER TABLE `year_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admitted_students`
--
ALTER TABLE `admitted_students`
  ADD CONSTRAINT `admitted_students_ibfk_1` FOREIGN KEY (`year_id`) REFERENCES `academic_years` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_values`
--
ALTER TABLE `student_values`
  ADD CONSTRAINT `student_values_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `admitted_students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_values_ibfk_2` FOREIGN KEY (`field_id`) REFERENCES `year_fields` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `year_fields`
--
ALTER TABLE `year_fields`
  ADD CONSTRAINT `year_fields_ibfk_1` FOREIGN KEY (`year_id`) REFERENCES `academic_years` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
