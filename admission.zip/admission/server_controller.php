<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
header('Content-Type: application/json');

/* admin */
if (isset($_POST['admin_login']))     { try { echo json_encode(admin_login($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['admin_logout']))    { try { echo json_encode(admin_logout()); }                catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['list_years']))      { try { echo json_encode(ok(['years' => list_years($con)])); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['create_year']))     { try { echo json_encode(create_year($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['toggle_year']))     { try { echo json_encode(toggle_year($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['list_students']))   { try { echo json_encode(list_students($con, $_POST)); }   catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['list_pending']))    { try { echo json_encode(list_pending($con, $_POST)); }    catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['delete_student']))  { try { echo json_encode(delete_student($con, $_POST)); }  catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['delete_students_bulk'])) { try { echo json_encode(delete_students_bulk($con, $_POST)); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['import_students'])) { try { echo json_encode(import_students($con, $_POST)); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['export_students'])) { try { echo json_encode(export_students($con, $_POST)); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['list_fields']))     { try { require_super(); echo json_encode(ok(['fields' => list_fields($con, $_POST['year_id'])])); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['add_field']))       { try { echo json_encode(add_field($con, $_POST)); }       catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['update_field']))    { try { echo json_encode(update_field($con, $_POST)); }    catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['edit_field']))      { try { echo json_encode(edit_field($con, $_POST)); }      catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['reorder_fields']))  { try { echo json_encode(reorder_fields($con, $_POST)); }  catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['delete_field']))    { try { echo json_encode(delete_field($con, $_POST)); }    catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['review_list']))     { try { echo json_encode(review_list($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['review_detail']))   { try { echo json_encode(review_detail($con, $_POST)); }   catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['set_decision']))    { try { echo json_encode(set_decision($con, $_POST)); }    catch (Throwable $e) { echo json_encode(caught($e)); } exit; }

if (isset($_POST['toggle_open_reg'])) { try { echo json_encode(toggle_open_reg($con, $_POST)); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['save_settings']))   { try { echo json_encode(save_settings($con, $_POST)); }   catch (Throwable $e) { echo json_encode(caught($e)); } exit; }

if (isset($_POST['search_students'])) { try { echo json_encode(search_students($con, $_POST)); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }

if (isset($_POST['list_users']))      { try { echo json_encode(list_users($con)); }              catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['create_user']))     { try { echo json_encode(create_user($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['toggle_user']))     { try { echo json_encode(toggle_user($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['reset_user_password'])) { try { echo json_encode(reset_user_password($con, $_POST)); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['delete_user']))     { try { echo json_encode(delete_user($con, $_POST)); }     catch (Throwable $e) { echo json_encode(caught($e)); } exit; }

/* student */
if (isset($_POST['get_settings']))    { try { echo json_encode(ok(['settings' => get_settings($con)])); } catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['student_login']))   { try { echo json_encode(student_login($con, $_POST)); }   catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['student_session'])) { try { echo json_encode(student_session($con)); }         catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['student_submit']))  { try { echo json_encode(student_submit($con, $_POST)); }  catch (Throwable $e) { echo json_encode(caught($e)); } exit; }
if (isset($_POST['student_logout']))  { try { echo json_encode(student_logout()); }              catch (Throwable $e) { echo json_encode(caught($e)); } exit; }

echo json_encode(fail('Unknown request'));