<?php
require_once __DIR__ . '/functions.php';

function brand_head($S, $title) {
    $c = preg_match('/^#[0-9a-fA-F]{6}$/', $S['primary_color']) ? $S['primary_color'] : '#696cff';
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title) ?> | <?= htmlspecialchars($S['college_name']) ?></title>
<link rel="icon" href="logo.png">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<link href="assets/style.css" rel="stylesheet">
<style>:root{--sn-primary:<?= $c ?>}</style></head>
<?php }

function layout_top($title, $active) {
    global $con;
    $S = get_settings($con);
    $role = $_SESSION['admin_role'] ?? 'admin';
    $name = $_SESSION['admin_name'] ?? 'Admin';
    $menu = [['years', 'admin.php', 'bx-calendar', 'Academic Years'], ['review', 'review.php', 'bx-check-shield', 'Review Submissions']];
    if ($role === 'super') { $menu[] = ['users', 'users.php', 'bx-user-plus', 'Users']; $menu[] = ['settings', 'settings.php', 'bx-cog', 'Settings']; }
    brand_head($S, $title); ?>
<body>
<aside class="sn-sidebar <?= $S['dark_sidebar'] === '1' ? 'dark' : '' ?>" id="sidebar">
  <a class="sn-brand" href="admin.php"><img src="logo.png" alt="logo"><span class="t"><?= htmlspecialchars($S['college_name']) ?><span class="s"><?= htmlspecialchars($S['college_location']) ?></span></span></a>
  <nav class="sn-menu">
    <div class="hdr">Admissions</div>
    <?php foreach ($menu as $m): ?>
      <a href="<?= $m[1] ?>" class="<?= $m[0] === $active ? 'active' : '' ?>"><i class="bx <?= $m[2] ?>"></i><?= $m[3] ?></a>
    <?php endforeach; ?>
    <div class="hdr">Student side</div>
    <a href="student.php" target="_blank"><i class="bx bx-link-external"></i>Student portal</a>
  </nav>
</aside>
<div class="sn-page">
  <nav class="sn-nav">
    <button class="sn-toggle" id="toggleMenu"><i class="bx bx-menu"></i></button>
    <div class="search" style="position:relative"><i class="bx bx-search fs-4 text-muted"></i><input id="gsearch" placeholder="Search a reference number..." autocomplete="off"><div id="gres" class="list-group shadow d-none" style="position:absolute;top:2.6rem;left:0;right:0;z-index:1100"></div></div>
    <div class="dropdown">
      <button class="sn-avatar" data-bs-toggle="dropdown"><?= htmlspecialchars(strtoupper(mb_substr($name, 0, 1))) ?></button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li class="px-3 py-2"><strong class="d-block"><?= htmlspecialchars($name) ?></strong><small class="text-muted"><?= $role === 'super' ? 'Super admin' : 'Admin' ?></small></li>
        <li><hr class="dropdown-divider"></li>
        <?php if ($role === 'super'): ?><li><a class="dropdown-item" href="settings.php"><i class="bx bx-cog me-2"></i>Settings</a></li><?php endif; ?>
        <li><a class="dropdown-item" href="#" id="logoutBtn"><i class="bx bx-power-off me-2"></i>Log out</a></li>
      </ul>
    </div>
  </nav>
  <div class="sn-content">
    <h4 class="fw-bold py-3 mb-3"><span class="text-muted fw-light">Admissions /</span> <?= htmlspecialchars($title) ?></h4>
<?php }

function layout_bottom() {
    global $con;
    $S = get_settings($con); ?>
  </div>
  <footer class="sn-footer"><span>&copy; <?= date('Y') ?> <?= htmlspecialchars($S['college_name']) ?>, <?= htmlspecialchars($S['college_location']) ?></span><span><?= htmlspecialchars($S['tagline']) ?></span></footer>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/app.js"></script>
<script>
$('#logoutBtn').on('click', e => { e.preventDefault(); api({admin_logout: true}).then(() => location.href = 'admin.php'); });
let gt;
$('#gsearch').on('input', function () {
  clearTimeout(gt); const q = this.value.trim();
  if (!q) return $('#gres').addClass('d-none').empty();
  gt = setTimeout(() => api({search_students: true, q}).then(r => {
    $('#gres').toggleClass('d-none', false).html(r.results.length ? r.results.map(s => `<a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" href="review.php?student=${s.id}"><span>${esc(s.reference_no)}<small class="text-muted d-block">${esc(s.year_name)}</small></span>${badge(s.status)}</a>`).join('') : '<div class="list-group-item text-muted">No match</div>');
  }), 250);
});
$(document).on('click', e => { if (!$(e.target).closest('.search').length) $('#gres').addClass('d-none'); });
$('#toggleMenu').on('click', () => $('#sidebar').toggleClass('show'));
</script>
<?php }