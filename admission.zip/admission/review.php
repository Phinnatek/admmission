<?php
require_once 'config.php';
require_once 'layout.php';
if (empty($_SESSION['admin_id'])) { header('Location: admin.php'); exit; }
layout_top('Review Submissions', 'review'); ?>
<div class="d-flex flex-wrap gap-2 mb-4">
  <select id="yf" class="form-select" style="max-width:220px"><option value="">All years</option></select>
  <select id="sf" class="form-select" style="max-width:200px"><option value="submitted">Awaiting review</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="all">Everything</option></select>
</div>
<div id="list" class="row g-3"></div>
<div class="offcanvas offcanvas-end" id="detail" style="width:min(640px,100%)">
  <div class="offcanvas-header"><h5 class="offcanvas-title" id="dTitle"></h5><button class="btn-close" data-bs-dismiss="offcanvas"></button></div>
  <div class="offcanvas-body" style="background:var(--sn-bg)">
    <div id="dBody" class="row g-3 mb-4"></div>
    <div id="dActions"></div>
  </div>
</div>
<?php layout_bottom(); ?>
<script>
const preYear = new URLSearchParams(location.search).get('year') || '';
let current = null, yearsLoaded = false;
const oc = new bootstrap.Offcanvas('#detail');
function draw(r) {
  if (!yearsLoaded) { r.years.forEach(y => $('#yf').append(`<option value="${y.id}">${esc(y.name)}</option>`)); $('#yf').val(preYear); yearsLoaded = true; }
  $('#list').html(r.students.length ? r.students.map(s => `<div class="col-md-6 col-xl-4"><div class="card h-100 open" role="button" data-id="${s.id}"><div class="card-body d-flex justify-content-between align-items-center"><div><h6 class="mb-1">${esc(s.reference_no)}</h6><small class="text-muted">${esc(s.year_name)}${s.submitted_at ? ' · ' + esc(s.submitted_at) : ''}</small></div>${badge(s.status)}</div></div></div>`).join('') : '<div class="col-12"><div class="card"><div class="card-body text-center py-5">Nothing to review here.</div></div></div>');
}
const load = () => api({review_list: true, year_id: (yearsLoaded ? $('#yf').val() : preYear), status: $('#sf').val()}).then(draw);
load();
$('#yf,#sf').on('change', load);
function showDetail(v) {
  current = v;
  $('#dTitle').html(`${esc(v.reference_no)} ${badge(v.status)}`);
  $('#dBody').html(detailCards(v.fields) || '<div class="col-12">No details requested for this year.</div>');
  let a = '';
  if (v.status === 'rejected' && v.reject_reason) a += `<div class="alert alert-danger">Rejected: ${esc(v.reject_reason)}</div>`;
  if (v.status === 'submitted' || v.status === 'rejected' || v.status === 'approved') a += `<textarea id="reason" class="form-control mb-3" rows="2" placeholder="Reason (required when rejecting)"></textarea>
    <div class="d-flex gap-2"><button class="btn btn-success flex-fill" data-d="approved">Approve</button><button class="btn btn-danger flex-fill" data-d="rejected">Reject</button></div>`;
  else a = '<div class="alert alert-secondary">The student has not submitted yet.</div>';
  $('#dActions').html(a);
}
$('#list').on('click', '.open', function () { api({review_detail: true, student_id: $(this).data('id')}).then(r => { showDetail(r.view); oc.show(); }); });
$('#dActions').on('click', '[data-d]', function () {
  api({set_decision: true, student_id: current.student_id, decision: $(this).data('d'), reason: $('#reason').val(), year_id: (yearsLoaded ? $('#yf').val() : preYear), status: $('#sf').val()})
    .then(r => { showDetail(r.view); draw(r); toast('Decision saved: ' + r.view.status); });
});
const preStudent = new URLSearchParams(location.search).get('student');
if (preStudent) api({review_detail: true, student_id: preStudent}).then(x => { showDetail(x.view); oc.show(); });
</script></body></html>