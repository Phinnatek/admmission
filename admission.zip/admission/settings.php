<?php
require_once 'config.php';
require_once 'layout.php';
if (empty($_SESSION['admin_id']) || ($_SESSION['admin_role'] ?? '') !== 'super') { header('Location: admin.php'); exit; }
$S = get_settings($con);
layout_top('Settings', 'settings'); ?>
<div class="row g-4">
  <div class="col-lg-8"><div class="card"><div class="card-body">
    <h5 class="mb-4">Branding and wording</h5>
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label">College name</label><input id="college_name" class="form-control" value="<?= htmlspecialchars($S['college_name']) ?>"></div>
      <div class="col-md-6"><label class="form-label">Location</label><input id="college_location" class="form-control" value="<?= htmlspecialchars($S['college_location']) ?>"></div>
      <div class="col-md-6"><label class="form-label">Tagline (footer)</label><input id="tagline" class="form-control" value="<?= htmlspecialchars($S['tagline']) ?>"></div>
      <div class="col-md-6"><label class="form-label">Student login label</label><input id="student_id_label" class="form-control" value="<?= htmlspecialchars($S['student_id_label']) ?>"></div>
      <div class="col-12"><label class="form-label">Student login message</label><textarea id="student_welcome" class="form-control" rows="2"><?= htmlspecialchars($S['student_welcome']) ?></textarea></div>
      <div class="col-md-4"><label class="form-label">Theme colour</label><input id="primary_color" type="color" class="form-control form-control-color w-100" value="<?= htmlspecialchars($S['primary_color']) ?>"></div>
      <div class="col-md-8 d-flex align-items-end"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="dark_sidebar" <?= $S['dark_sidebar'] === '1' ? 'checked' : '' ?>><label class="form-check-label" for="dark_sidebar">Dark sidebar</label></div></div>
    </div>
    <button id="save" class="btn btn-primary mt-4">Save changes</button>
  </div></div></div>
  <div class="col-lg-4"><div class="card"><div class="card-body text-center">
    <h5 class="mb-3">Logo</h5>
    <img id="logoPrev" src="logo.png?v=1" style="width:110px;height:110px;object-fit:contain" class="mb-3">
    <input type="file" id="logo" class="form-control" accept="image/png">
    <small class="text-muted d-block mt-2">PNG, up to 1MB. It replaces logo.png on the server.</small>
  </div></div></div>
</div>
<?php layout_bottom(); ?>
<script>
$('#save').on('click', async () => {
  const d = {save_settings: true, dark_sidebar: $('#dark_sidebar').is(':checked') ? '1' : '0'};
  ['college_name', 'college_location', 'tagline', 'student_id_label', 'student_welcome', 'primary_color'].forEach(k => d[k] = $('#' + k).val());
  const f = $('#logo')[0].files[0];
  if (f) d.logo_b64 = await fileToB64(f);
  api(d).then(r => { toast('Settings saved'); $('#logoPrev').attr('src', 'logo.png?v=' + r.logo_version); setTimeout(() => location.reload(), 700); });
});
</script></body></html>