<?php
require_once 'config.php';
require_once 'layout.php';
if (empty($_SESSION['admin_id']) || ($_SESSION['admin_role'] ?? '') !== 'super') { header('Location: admin.php'); exit; }
layout_top('Users', 'users'); ?>
<div class="card mb-4"><div class="card-body">
  <h5 class="mb-4">Add a user</h5>
  <div class="row g-3 align-items-end">
    <div class="col-md-3"><label class="form-label">Full name</label><input id="full_name" class="form-control"></div>
    <div class="col-md-3"><label class="form-label">Username</label><input id="username" class="form-control" autocomplete="off"></div>
    <div class="col-md-2"><label class="form-label">Password</label><input id="password" type="password" class="form-control" autocomplete="new-password" placeholder="8+ characters"></div>
    <div class="col-md-2"><label class="form-label">Role</label><select id="role" class="form-select"><option value="admin">Admin</option><option value="super">Super admin</option></select></div>
    <div class="col-md-2"><button id="addUser" class="btn btn-primary w-100">Create user</button></div>
  </div>
  <small class="text-muted d-block mt-3">Admin: can view academic years and review submissions only. Super admin: full access, including years, Manage, settings and users.</small>
</div></div>
<div id="users" class="row g-4"></div>
<?php layout_bottom(); ?>
<script>
let ME = 0;
const userCard = u => `<div class="col-md-6 col-xl-4"><div class="card h-100"><div class="card-body">
  <div class="d-flex justify-content-between align-items-start mb-3">
    <div class="d-flex gap-3"><span class="avatar-init bg-label-primary"><i class="bx bx-user"></i></span><div><h6 class="mb-0">${esc(u.full_name || u.username)}</h6><small class="text-muted">@${esc(u.username)}</small></div></div>
    <div class="text-end"><span class="badge bg-label-${u.role === 'super' ? 'primary' : 'info'}">${u.role === 'super' ? 'Super admin' : 'Admin'}</span><br><span class="badge bg-label-${+u.is_active ? 'success' : 'secondary'} mt-1">${+u.is_active ? 'Active' : 'Disabled'}</span></div>
  </div>
  <div class="input-group input-group-sm mb-3"><input type="password" class="form-control pw" placeholder="New password" autocomplete="new-password"><button class="btn btn-outline-primary reset" data-id="${u.id}">Reset</button></div>
  ${+u.id === ME ? '<small class="text-muted">This is you.</small>' : `<div class="d-flex gap-2"><button class="btn btn-sm btn-outline-secondary flex-fill toggle" data-id="${u.id}">${+u.is_active ? 'Disable' : 'Enable'}</button><button class="btn btn-sm btn-outline-danger flex-fill del" data-id="${u.id}">Delete</button></div>`}
</div></div></div>`;
const draw = r => { ME = +r.me; $('#users').html(r.users.map(userCard).join('')); };
api({list_users: true}).then(draw);
$('#addUser').on('click', () => api({create_user: true, full_name: $('#full_name').val(), username: $('#username').val(), password: $('#password').val(), role: $('#role').val()})
  .then(r => { draw(r); $('#full_name,#username,#password').val(''); toast('User created'); }));
$('#users').on('click', '.toggle', function () { api({toggle_user: true, user_id: $(this).data('id')}).then(r => { draw(r); toast('User updated'); }); });
$('#users').on('click', '.reset', function () { api({reset_user_password: true, user_id: $(this).data('id'), password: $(this).siblings('.pw').val()}).then(r => { draw(r); toast('Password changed'); }); });
$('#users').on('click', '.del', function () { if (confirm('Delete this user?')) api({delete_user: true, user_id: $(this).data('id')}).then(r => { draw(r); toast('User deleted'); }); });
</script></body></html>
