<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'layout.php';
if (empty($_SESSION['admin_id']) || ($_SESSION['admin_role'] ?? '') !== 'super') { header('Location: admin.php'); exit; }
$year = get_year($con, $_GET['year'] ?? 0);
if (!$year) { header('Location: admin.php'); exit; }
layout_top('Manage ' . $year['name'], 'years'); ?>
<script>const YEAR_ID = <?= (int)$year['id'] ?>;</script>
<div class="card mb-4"><div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-3">
  <div><h6 class="mb-1">Open registration</h6><small class="text-muted">When on, a student whose number is not in the list can enter it at login and is added to this year automatically.</small></div>
  <div class="form-check form-switch fs-5 mb-0"><input class="form-check-input" type="checkbox" id="openReg" <?= $year['open_registration'] ? 'checked' : '' ?>></div>
</div></div>
<ul class="nav nav-tabs mb-4">
  <li class="nav-item"><button id="appTabBtn" class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabApplicants"><i class="bx bx-group"></i> Applicants</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabFields"><i class="bx bx-list-check"></i> Requested details</button></li>
  <li class="nav-item d-none"><button id="bulkTabBtn" class="nav-link" data-bs-toggle="tab" data-bs-target="#tabBulk"></button></li>
  <li class="ms-auto"><a class="btn btn-sm btn-outline-primary" href="review.php?year=<?= (int)$year['id'] ?>">Review submissions</a></li>
</ul>
<div class="tab-content p-0"><div class="tab-pane fade show active" id="tabApplicants">
  <div class="row g-3 mb-4" id="stats"></div>
  <div class="card mb-4"><div class="card-body d-flex flex-wrap gap-3 align-items-end">
    <div><label class="form-label mb-1">Upload admitted reference numbers (.xlsx or .csv, first column)</label><input type="file" id="xfile" class="form-control" accept=".xlsx,.xls,.csv"></div>
    <button id="importBtn" class="btn btn-primary"><i class="bx bx-upload"></i> Import</button>
    <button id="exportBtn" class="btn btn-outline-secondary ms-auto"><i class="bx bx-download"></i> Export to Excel</button>
  </div></div>
  <div class="d-flex flex-wrap gap-2 mb-3">
    <input id="q" class="form-control" style="max-width:260px" placeholder="Search reference number">
    <select id="sf" class="form-select" style="max-width:180px"><option value="">All statuses</option><option>pending</option><option>submitted</option><option>approved</option><option>rejected</option></select>
    <button id="openBulk" class="btn btn-outline-danger ms-auto"><i class="bx bx-trash"></i> Delete pending students</button>
  </div>
  <div id="students" class="row g-3"></div>
</div>
<div class="tab-pane fade" id="tabBulk">
  <div class="card mb-4"><div class="card-body d-flex flex-wrap gap-2 align-items-center">
    <div class="me-auto"><h5 class="mb-1">Delete pending students</h5><small class="text-muted">Only students who have not submitted are listed. Deleting cannot be undone.</small></div>
    <input id="bq" class="form-control" style="max-width:200px" placeholder="Filter list">
    <button id="selAll" class="btn btn-outline-primary">Select all</button>
    <button id="deselAll" class="btn btn-outline-secondary">Deselect all</button>
    <button id="bulkDel" class="btn btn-danger" disabled>Delete selected (0)</button>
    <button id="bulkBack" class="btn btn-outline-secondary">Back</button>
  </div></div>
  <div id="bulkList" class="row g-3"></div>
</div>
<div class="tab-pane fade" id="tabFields">
  <div class="card mb-4"><div class="card-body">
    <h6>Quick add</h6>
    <div class="d-flex flex-wrap gap-2 mb-4" id="presets"></div>
    <h6>Add your own</h6>
    <div class="row g-3 align-items-end">
      <div class="col-md-4"><label class="form-label mb-1">Field name</label><input id="flabel" class="form-control" placeholder="e.g. Guardian phone"></div>
      <div class="col-md-2"><label class="form-label mb-1">Type</label><select id="ftype" class="form-select"><option value="text">Text</option><option value="textarea">Long text</option><option value="email">Email</option><option value="tel">Phone</option><option value="date">Date</option><option value="number">Number</option><option value="file">File upload</option><option value="select">Dropdown (choices)</option></select></div>
      <div class="col-md-2"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="freq" checked><label class="form-check-label" for="freq">Required</label></div></div>
      <div class="col-md-2"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="fupd"><label class="form-check-label" for="fupd">Student can update later</label></div></div>
      <div class="col-md-2"><button id="addField" class="btn btn-primary w-100">Add field</button></div>
      <div class="col-12 d-none" id="optWrap"><label class="form-label mb-1">Choices (one per line)</label><textarea id="fopts" class="form-control" rows="3" placeholder="Male&#10;Female"></textarea></div>
    </div>
  </div></div>
  <div id="fields" class="row g-3"></div>
</div></div>
<?php layout_bottom(); ?>
<script>
const PRESETS = [['Gender','select','Male\nFemale'],['Last name','text'],['First name','text'],['Other name','text'],['Date of birth','date'],['Ghana Card number','text'],['NHIS number','text'],['Email','email'],['Telephone','tel'],['Passport photo','file'],['Bank draft payment','file']];
$('#presets').html(PRESETS.map(p => `<span class="badge bg-label-primary chip py-2 px-3" data-l="${p[0]}" data-t="${p[1]}" data-o="${esc(p[2] || '')}">+ ${p[0]}</span>`).join(''));

$('#openReg').on('change', () => api({toggle_open_reg: true, year_id: YEAR_ID}).then(r => toast(+r.year.open_registration ? 'Open registration is on' : 'Open registration is off')));

/* ----- applicants ----- */
const stat = (l, v, c) => `<div class="col-6 col-md"><div class="card"><div class="card-body py-3"><small>${l}</small><h4 class="mb-0 text-${c}">${v}</h4></div></div></div>`;
function drawStudents(r) {
  const s = r.stats;
  $('#stats').html(stat('Admitted', s.total, 'primary') + stat('Not submitted', s.pending, 'secondary') + stat('Awaiting review', s.submitted, 'warning') + stat('Approved', s.approved, 'success') + stat('Rejected', s.rejected, 'danger'));
  $('#students').html(r.students.length ? r.students.map(x => `<div class="col-md-6 col-xl-4"><div class="card"><div class="card-body d-flex justify-content-between align-items-center"><div><h6 class="mb-1">${esc(x.reference_no)}</h6><small class="text-muted">${x.submitted_at ? 'Submitted ' + esc(x.submitted_at) : 'Not submitted yet'}</small></div><div class="d-flex align-items-center gap-1">${badge(x.status)}${x.status === 'pending' ? `<button class="btn btn-sm btn-icon text-danger delS" data-id="${x.id}" title="Delete"><i class="bx bx-trash"></i></button>` : ''}</div></div></div></div>`).join('') : '<div class="col-12"><div class="card"><div class="card-body text-center py-5">No admitted students yet. Upload a spreadsheet of reference numbers above.</div></div></div>');
}
const loadStudents = () => api({list_students: true, year_id: YEAR_ID, q: $('#q').val(), status: $('#sf').val()}).then(drawStudents);
loadStudents();
$('#q').on('input', loadStudents); $('#sf').on('change', loadStudents);
$('#importBtn').on('click', async () => {
  const f = $('#xfile')[0].files[0];
  if (!f) return toast('Choose a spreadsheet first', 'danger');
  const b64 = await fileToB64(f);
  api({import_students: true, year_id: YEAR_ID, file_b64: b64}).then(r => { drawStudents(r); $('#xfile').val(''); toast(`${r.added} added, ${r.skipped} already existed`); });
});
$('#students').on('click', '.delS', function () {
  if (!confirm('Delete this student? This cannot be undone.')) return;
  api({delete_student: true, year_id: YEAR_ID, student_id: $(this).data('id'), q: $('#q').val(), status: $('#sf').val()}).then(r => { drawStudents(r); toast('Student deleted'); });
});

/* ----- bulk delete (hidden tab) ----- */
let PENDING = [], SEL = new Set();
const visiblePending = () => { const q = $('#bq').val().toLowerCase(); return PENDING.filter(s => s.reference_no.toLowerCase().includes(q)); };
function bulkDraw() {
  const vis = visiblePending();
  $('#bulkList').html(vis.length ? vis.map(s => `<div class="col-md-6 col-xl-4"><label class="card h-100 open ${SEL.has(+s.id) ? 'border border-danger' : ''}" style="cursor:pointer"><div class="card-body d-flex align-items-center gap-3"><input type="checkbox" class="form-check-input m-0 bsel" data-id="${s.id}" ${SEL.has(+s.id) ? 'checked' : ''}><h6 class="mb-0">${esc(s.reference_no)}</h6></div></label></div>`).join('') : '<div class="col-12"><div class="card"><div class="card-body text-center py-5">No pending students to delete.</div></div></div>');
  $('#bulkDel').prop('disabled', !SEL.size).text(`Delete selected (${SEL.size})`);
}
$('#openBulk').on('click', () => api({list_pending: true, year_id: YEAR_ID}).then(r => { PENDING = r.students; SEL.clear(); $('#bq').val(''); bulkDraw(); bootstrap.Tab.getOrCreateInstance('#bulkTabBtn').show(); }));
$('#bulkBack').on('click', () => bootstrap.Tab.getOrCreateInstance('#appTabBtn').show());
$('#bq').on('input', bulkDraw);
$('#selAll').on('click', () => { visiblePending().forEach(s => SEL.add(+s.id)); bulkDraw(); });
$('#deselAll').on('click', () => { SEL.clear(); bulkDraw(); });
$('#bulkList').on('change', '.bsel', function () { const id = +$(this).data('id'); this.checked ? SEL.add(id) : SEL.delete(id); bulkDraw(); });
$('#bulkDel').on('click', () => {
  if (!SEL.size || !confirm(`Delete ${SEL.size} pending student(s)? This cannot be undone.`)) return;
  api({delete_students_bulk: true, year_id: YEAR_ID, ids: JSON.stringify([...SEL]), q: $('#q').val(), status: $('#sf').val()}).then(r => {
    PENDING = r.pending; SEL.clear(); bulkDraw(); drawStudents(r);
    toast(`${r.deleted} deleted` + (r.skipped ? `, ${r.skipped} skipped (already submitted)` : ''));
  });
});

$('#exportBtn').on('click', () => api({export_students: true, year_id: YEAR_ID}).then(r => downloadB64(r.file_b64, r.filename)));

/* ----- dynamic fields ----- */
const TYPE_LABEL = {text:'Text',textarea:'Long text',email:'Email',tel:'Phone',date:'Date',number:'Number',file:'File upload',select:'Dropdown'};
const sw = (f, col, label) => `<div class="form-check form-switch"><input class="form-check-input sw" type="checkbox" data-id="${f.id}" data-col="${col}" ${+f[col] ? 'checked' : ''}><label class="form-check-label">${label}</label></div>`;
let FIELDS = [], EDIT_ID = null;
const editCard = f => `<div class="col-md-6 col-xl-4 fcol" data-id="${f.id}"><div class="card h-100 border border-primary"><div class="card-body">
  <label class="form-label mb-1">Field name</label><input class="form-control form-control-sm mb-2 e-label" value="${esc(f.label)}">
  <label class="form-label mb-1">Type</label><select class="form-select form-select-sm mb-2 e-type">${Object.entries(TYPE_LABEL).map(([k, v]) => `<option value="${k}" ${f.type === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
  <div class="e-opts mb-2 ${f.type === 'select' ? '' : 'd-none'}"><label class="form-label mb-1">Choices (one per line)</label><textarea class="form-control form-control-sm e-optv" rows="3">${esc(JSON.parse(f.options || '[]').join('\n'))}</textarea></div>
  <div class="form-check form-switch"><input class="form-check-input e-req" type="checkbox" ${+f.is_required ? 'checked' : ''}><label class="form-check-label">Required</label></div>
  <div class="form-check form-switch mb-3"><input class="form-check-input e-upd" type="checkbox" ${+f.allow_update ? 'checked' : ''}><label class="form-check-label">Student can update after submitting</label></div>
  <div class="d-flex gap-2"><button class="btn btn-sm btn-primary flex-fill e-save" data-id="${f.id}">Save</button><button class="btn btn-sm btn-outline-secondary flex-fill e-cancel">Cancel</button></div>
</div></div></div>`;
const viewCard = (f, i, n) => `<div class="col-md-6 col-xl-4 fcol" draggable="true" data-id="${f.id}"><div class="card h-100"><div class="card-body">
  <div class="d-flex justify-content-between align-items-start mb-2">
    <div class="d-flex gap-2"><i class="bx bx-grid-vertical fs-4 text-muted" style="cursor:grab" title="Drag to reorder"></i><div><h6 class="mb-0">${i + 1}. ${esc(f.label)}</h6><small class="text-muted">${TYPE_LABEL[f.type]}${f.type === 'select' ? ': ' + esc(JSON.parse(f.options || '[]').join(', ')) : ''}</small></div></div>
    <div class="d-flex gap-1">
      <button class="btn btn-sm btn-icon edit" data-id="${f.id}" title="Edit"><i class="bx bx-edit-alt"></i></button>
      <button class="btn btn-sm btn-icon mv" data-id="${f.id}" data-dir="-1" title="Move up" ${i === 0 ? 'disabled' : ''}><i class="bx bx-chevron-up"></i></button>
      <button class="btn btn-sm btn-icon mv" data-id="${f.id}" data-dir="1" title="Move down" ${i === n - 1 ? 'disabled' : ''}><i class="bx bx-chevron-down"></i></button>
      <button class="btn btn-sm btn-icon text-danger del" data-id="${f.id}" title="Remove"><i class="bx bx-trash"></i></button>
    </div>
  </div>
  ${sw(f, 'is_required', 'Required')}${sw(f, 'allow_update', 'Student can update after submitting')}
</div></div></div>`;
const drawFields = fs => {
  FIELDS = fs;
  $('#fields').html(fs.length ? fs.map((f, i) => +f.id === EDIT_ID ? editCard(f) : viewCard(f, i, fs.length)).join('') : '<div class="col-12"><div class="card"><div class="card-body text-center py-5">No details requested yet. Add fields above and students will see them when they log in.</div></div></div>');
};
$('#fields').on('click', '.edit', function () { EDIT_ID = +$(this).data('id'); drawFields(FIELDS); });
$('#fields').on('click', '.e-cancel', () => { EDIT_ID = null; drawFields(FIELDS); });
$('#fields').on('change', '.e-type', function () { $(this).closest('.card').find('.e-opts').toggleClass('d-none', this.value !== 'select'); });
$('#fields').on('click', '.e-save', function () {
  const c = $(this).closest('.card');
  api({edit_field: true, year_id: YEAR_ID, field_id: $(this).data('id'), label: c.find('.e-label').val(), type: c.find('.e-type').val(), options: c.find('.e-optv').val(),
       is_required: c.find('.e-req').is(':checked') ? 1 : 0, allow_update: c.find('.e-upd').is(':checked') ? 1 : 0}).then(r => { EDIT_ID = null; drawFields(r.fields); toast('Field updated'); });
});
const saveOrder = ids => api({reorder_fields: true, year_id: YEAR_ID, order: JSON.stringify(ids)}).then(r => { drawFields(r.fields); toast('Order saved'); });
$('#fields').on('click', '.mv', function () {
  const ids = FIELDS.map(f => +f.id), i = ids.indexOf(+$(this).data('id')), j = i + (+$(this).data('dir'));
  if (j < 0 || j >= ids.length) return;
  [ids[i], ids[j]] = [ids[j], ids[i]];
  saveOrder(ids);
});
let dragId = null;
$('#fields')
  .on('dragstart', '.fcol', function (e) { dragId = +$(this).data('id'); $(this).css('opacity', .4); e.originalEvent.dataTransfer.effectAllowed = 'move'; e.originalEvent.dataTransfer.setData('text/plain', dragId); })
  .on('dragend', '.fcol', function () { $(this).css('opacity', 1); $('#fields .card').removeClass('border border-primary'); })
  .on('dragover', '.fcol', function (e) { e.preventDefault(); $(this).find('.card').addClass('border border-primary'); })
  .on('dragleave', '.fcol', function () { $(this).find('.card').removeClass('border border-primary'); })
  .on('drop', '.fcol', function (e) {
    e.preventDefault();
    const to = +$(this).data('id');
    if (dragId === null || dragId === to) return;
    const ids = FIELDS.map(f => +f.id), from = ids.indexOf(dragId), target = ids.indexOf(to);
    ids.splice(from, 1); ids.splice(target, 0, dragId); dragId = null;
    saveOrder(ids);
  });
api({list_fields: true, year_id: YEAR_ID}).then(r => drawFields(r.fields));
const addField = (label, type, req, upd, options = '') => api({add_field: true, year_id: YEAR_ID, label, type, options, is_required: req ? 1 : 0, allow_update: upd ? 1 : 0}).then(r => { drawFields(r.fields); toast('Field added'); });
$('#presets').on('click', '.chip', function () { addField($(this).data('l'), $(this).data('t'), true, false, $(this).data('o')); });
$('#addField').on('click', () => addField($('#flabel').val(), $('#ftype').val(), $('#freq').is(':checked'), $('#fupd').is(':checked'), $('#fopts').val()).then(() => { $('#flabel,#fopts').val(''); }));
$('#ftype').on('change', function () { $('#optWrap').toggleClass('d-none', this.value !== 'select'); });
$('#fields').on('change', '.sw', function () { api({update_field: true, year_id: YEAR_ID, field_id: $(this).data('id'), column: $(this).data('col'), value: this.checked ? 1 : 0}).then(r => drawFields(r.fields)); });
$('#fields').on('click', '.del', function () { if (confirm('Remove this field? Answers students already gave will be deleted.')) api({delete_field: true, year_id: YEAR_ID, field_id: $(this).data('id')}).then(r => { drawFields(r.fields); toast('Field removed'); }); });
</script></body></html>