<?php
require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/* ---------- response + guards ---------- */
function ok(array $data = []) { return ['status' => 'success'] + $data; }
function fail($msg)           { return ['status' => 'error', 'message' => $msg]; }
function caught(Throwable $e) { return fail($e->getMessage()); }

function require_admin()   { if (empty($_SESSION['admin_id']))   throw new RuntimeException('Please log in as admin'); }
function require_super() {
    require_admin();
    if (($_SESSION['admin_role'] ?? '') !== 'super') throw new RuntimeException('Only a super admin can do this');
}
function require_student() { if (empty($_SESSION['student_id'])) throw new RuntimeException('Please log in with your reference number'); return (int)$_SESSION['student_id']; }

/* ---------- admin auth ---------- */
function admin_login($con, $p) {
    $st = $con->prepare('SELECT * FROM admins WHERE username=?');
    $st->execute([trim($p['username'] ?? '')]);
    $a = $st->fetch();
    if (!$a || !password_verify($p['password'] ?? '', $a['password_hash'])) throw new RuntimeException('Wrong username or password');
    session_regenerate_id(true);
    if (!(int)$a['is_active']) throw new RuntimeException('This account is disabled. Contact the super admin');
    $_SESSION['admin_id'] = (int)$a['id'];
    $_SESSION['admin_role'] = $a['role'];
    $_SESSION['admin_name'] = $a['full_name'] ?: $a['username'];
    return ok();
}
function admin_logout() { session_destroy(); return ok(); }

/* ---------- academic years ---------- */
function get_year($con, $id) {
    $st = $con->prepare('SELECT * FROM academic_years WHERE id=?');
    $st->execute([(int)$id]);
    return $st->fetch();
}
function list_years($con) {
    require_admin();
    return $con->query("SELECT y.*,
        (SELECT COUNT(*) FROM admitted_students s WHERE s.year_id=y.id) total,
        (SELECT COUNT(*) FROM admitted_students s WHERE s.year_id=y.id AND s.status='submitted') submitted,
        (SELECT COUNT(*) FROM admitted_students s WHERE s.year_id=y.id AND s.status='approved') approved
        FROM academic_years y ORDER BY y.id DESC")->fetchAll();
}
function create_year($con, $p) {
    require_super();
    $name = trim($p['name'] ?? '');
    if ($name === '') throw new RuntimeException('Enter an academic year, e.g. 2026/2027');
    $con->prepare('INSERT INTO academic_years(name) VALUES(?)')->execute([$name]);
    return ok(['years' => list_years($con)]);
}
function toggle_year($con, $p) {
    require_super();
    $con->prepare("UPDATE academic_years SET status=IF(status='open','closed','open') WHERE id=?")->execute([(int)$p['year_id']]);
    return ok(['years' => list_years($con), 'year' => get_year($con, $p['year_id'])]);
}

/* ---------- applicants ---------- */
function year_stats($con, $yid) {
    $st = $con->prepare('SELECT status, COUNT(*) c FROM admitted_students WHERE year_id=? GROUP BY status');
    $st->execute([$yid]);
    $o = ['pending' => 0, 'submitted' => 0, 'approved' => 0, 'rejected' => 0];
    foreach ($st->fetchAll() as $r) $o[$r['status']] = (int)$r['c'];
    $o['total'] = array_sum($o);
    return $o;
}
function list_students($con, $p) {
    require_super();
    $yid = (int)$p['year_id'];
    $sql = 'SELECT id, reference_no, status, submitted_at FROM admitted_students WHERE year_id=?';
    $args = [$yid];
    if (!empty($p['status'])) { $sql .= ' AND status=?'; $args[] = $p['status']; }
    if (!empty($p['q']))      { $sql .= ' AND reference_no LIKE ?'; $args[] = '%' . trim($p['q']) . '%'; }
    $st = $con->prepare($sql . ' ORDER BY id DESC LIMIT 300');
    $st->execute($args);
    return ok(['students' => $st->fetchAll(), 'stats' => year_stats($con, $yid)]);
}
function import_students($con, $p) {
    require_super();
    $yid = (int)$p['year_id'];
    $raw = base64_decode($p['file_b64'] ?? '', true);
    if (!$raw) throw new RuntimeException('The uploaded file could not be read');
    $tmp = tempnam(sys_get_temp_dir(), 'imp');
    file_put_contents($tmp, $raw);
    try { $rows = IOFactory::load($tmp)->getActiveSheet()->toArray(null, true, true, false); }
    finally { @unlink($tmp); }
    $ins = $con->prepare('INSERT IGNORE INTO admitted_students(year_id, reference_no) VALUES(?,?)');
    $added = 0; $skipped = 0;
    foreach ($rows as $i => $r) {
        $ref = trim((string)($r[0] ?? ''));
        if ($ref === '' || ($i === 0 && stripos($ref, 'ref') !== false)) continue;
        $ins->execute([$yid, $ref]);
        $ins->rowCount() ? $added++ : $skipped++;
    }
    return ok(['added' => $added, 'skipped' => $skipped]) + list_students($con, ['year_id' => $yid]);
}
function export_students($con, $p) {
    require_super();
    $yid = (int)$p['year_id'];
    $year = get_year($con, $yid);
    $fields = $con->prepare('SELECT * FROM year_fields WHERE year_id=? ORDER BY sort_order,id');
    $fields->execute([$yid]);
    $fields = $fields->fetchAll();
    $ss = new Spreadsheet();
    $sh = $ss->getActiveSheet();
    $head = array_merge(['Reference No', 'Status'], array_column($fields, 'label'));
    $sh->fromArray($head, null, 'A1');
    $studs = $con->prepare('SELECT * FROM admitted_students WHERE year_id=? ORDER BY id');
    $studs->execute([$yid]);
    $val = $con->prepare('SELECT field_id, value FROM student_values WHERE student_id=?');
    $row = 2;
    foreach ($studs->fetchAll() as $s) {
        $val->execute([$s['id']]);
        $map = array_column($val->fetchAll(), 'value', 'field_id');
        $line = [$s['reference_no'], $s['status']];
        foreach ($fields as $f) $line[] = $map[$f['id']] ?? '';
        $sh->fromArray($line, null, 'A' . $row++);
    }
    ob_start();
    (new Xlsx($ss))->save('php://output');
    $bin = ob_get_clean();
    return ok(['file_b64' => base64_encode($bin), 'filename' => 'admission_' . preg_replace('/\W+/', '_', $year['name']) . '.xlsx']);
}

/* ---------- dynamic fields ---------- */
function list_fields($con, $yid) {
    $st = $con->prepare('SELECT * FROM year_fields WHERE year_id=? ORDER BY sort_order,id');
    $st->execute([(int)$yid]);
    return $st->fetchAll();
}
function add_field($con, $p) {
    require_super();
    $types = ['text', 'textarea', 'email', 'tel', 'date', 'number', 'file', 'select'];
    $label = trim($p['label'] ?? '');
    $type = $p['type'] ?? 'text';
    if ($label === '' || !in_array($type, $types, true)) throw new RuntimeException('Give the field a name and a valid type');
    $yid = (int)$p['year_id'];
    $opts = field_options($type, $p['options'] ?? '');
    $n = $con->prepare('SELECT COALESCE(MAX(sort_order),0)+1 FROM year_fields WHERE year_id=?');
    $n->execute([$yid]);
    $con->prepare('INSERT INTO year_fields(year_id,label,type,options,is_required,allow_update,sort_order) VALUES(?,?,?,?,?,?,?)')
        ->execute([$yid, $label, $type, $opts, empty($p['is_required']) ? 0 : 1, empty($p['allow_update']) ? 0 : 1, $n->fetchColumn()]);
    return ok(['fields' => list_fields($con, $yid)]);
}
function update_field($con, $p) {
    require_super();
    $col = $p['column'] ?? '';
    if (!in_array($col, ['is_required', 'allow_update'], true)) throw new RuntimeException('Invalid setting');
    $con->prepare("UPDATE year_fields SET $col=? WHERE id=?")->execute([empty($p['value']) ? 0 : 1, (int)$p['field_id']]);
    return ok(['fields' => list_fields($con, $p['year_id'])]);
}
function delete_field($con, $p) {
    require_super();
    $con->prepare('DELETE FROM year_fields WHERE id=?')->execute([(int)$p['field_id']]);
    return ok(['fields' => list_fields($con, $p['year_id'])]);
}

/* ---------- student view (used by student and admin review) ---------- */
function student_view($con, $sid) {
    $s = $con->prepare('SELECT s.*, y.name year_name, y.status year_status FROM admitted_students s JOIN academic_years y ON y.id=s.year_id WHERE s.id=?');
    $s->execute([$sid]);
    $st = $s->fetch();
    if (!$st) throw new RuntimeException('Record not found');
    $f = $con->prepare('SELECT f.*, v.value FROM year_fields f LEFT JOIN student_values v ON v.field_id=f.id AND v.student_id=? WHERE f.year_id=? ORDER BY f.sort_order,f.id');
    $f->execute([$sid, $st['year_id']]);
    $open = $st['year_status'] === 'open';
    $all = $open && in_array($st['status'], ['pending', 'rejected'], true);
    $fields = []; $any = false;
    foreach ($f->fetchAll() as $r) {
        $edit = $all || ($open && $st['status'] === 'submitted' && $r['allow_update']);
        $any = $any || $edit;
        $fields[] = ['id' => (int)$r['id'], 'label' => $r['label'], 'type' => $r['type'], 'options' => $r['options'] ? json_decode($r['options'], true) : [], 'required' => (bool)$r['is_required'], 'value' => $r['value'], 'editable' => $edit];
    }
    return ['student_id' => (int)$st['id'], 'reference_no' => $st['reference_no'], 'year' => $st['year_name'], 'status' => $st['status'],
            'reject_reason' => $st['reject_reason'], 'can_edit' => $any, 'fields' => $fields];
}

/* ---------- student side ---------- */
function student_login($con, $p) {
    $ref = trim($p['reference_no'] ?? '');
    if ($ref === '') throw new RuntimeException('Enter your number to continue');
    $st = $con->prepare('SELECT id FROM admitted_students WHERE reference_no=? ORDER BY year_id DESC LIMIT 1');
    $st->execute([$ref]);
    $id = $st->fetchColumn();
    if (!$id) {
        // open registration: admin allowed any student to enter their own number this year
        $y = $con->query("SELECT id FROM academic_years WHERE status='open' AND open_registration=1 ORDER BY id DESC LIMIT 1")->fetchColumn();
        if (!$y) throw new RuntimeException('Number not found. Check it and try again');
        if (!preg_match('#^[A-Za-z0-9/\-_. ]{3,60}$#', $ref)) throw new RuntimeException('Use only letters, numbers, / - _ . (3 to 60 characters)');
        $con->prepare('INSERT INTO admitted_students(year_id, reference_no) VALUES(?,?)')->execute([$y, $ref]);
        $id = $con->lastInsertId();
    }
    session_regenerate_id(true);
    $_SESSION['student_id'] = (int)$id;
    return ok(['view' => student_view($con, (int)$id)]);
}
function student_session($con) {
    if (empty($_SESSION['student_id'])) return ok(['view' => null]);
    try { return ok(['view' => student_view($con, (int)$_SESSION['student_id'])]); }
    catch (Throwable $e) { unset($_SESSION['student_id']); return ok(['view' => null]); } // record was removed
}
function student_logout() { unset($_SESSION['student_id']); return ok(); }

function save_upload($yid, $sid, $name, $b64) {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'pdf'], true)) throw new RuntimeException('Only JPG, PNG or PDF files are allowed');
    $bin = base64_decode(preg_replace('#^data:.*?;base64,#', '', $b64), true);
    if ($bin === false || strlen($bin) > 2 * 1024 * 1024) throw new RuntimeException('File is invalid or larger than 2MB');
    $dir = __DIR__ . "/uploads/$yid";
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $fn = $sid . '_' . bin2hex(random_bytes(8)) . ".$ext";
    file_put_contents("$dir/$fn", $bin);
    return "uploads/$yid/$fn";
}
function student_submit($con, $p) {
    $sid = require_student();
    $view = student_view($con, $sid);
    if (!$view['can_edit']) throw new RuntimeException('Your details can no longer be changed');
    $vals = json_decode($p['values'] ?? '{}', true) ?: [];
    $files = json_decode($p['files'] ?? '{}', true) ?: [];
    $yid = (int)$con->query("SELECT year_id FROM admitted_students WHERE id=$sid")->fetchColumn();
    $up = $con->prepare('INSERT INTO student_values(student_id,field_id,value) VALUES(?,?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)');
    $con->beginTransaction();
    try {
        foreach ($view['fields'] as $f) {
            if (!$f['editable']) continue;
            $v = trim((string)($vals[$f['id']] ?? ''));
            if ($f['type'] === 'file') {
                if (!empty($files[$f['id']]['data'])) $v = save_upload($yid, $sid, $files[$f['id']]['name'], $files[$f['id']]['data']);
                else $v = $f['value'] ?? '';
            }
            if ($v === '' && $f['required']) throw new RuntimeException($f['label'] . ' is required');
            if ($v !== '' && $f['type'] === 'select' && !in_array($v, $f['options'], true)) throw new RuntimeException('Pick a valid choice for ' . $f['label']);
            if ($v !== '' && $f['type'] === 'email' && !filter_var($v, FILTER_VALIDATE_EMAIL)) throw new RuntimeException($f['label'] . ' is not a valid email');
            if ($v !== '' && $f['type'] === 'date' && !strtotime($v)) throw new RuntimeException($f['label'] . ' is not a valid date');
            if ($v !== '' && $f['type'] === 'number' && !is_numeric($v)) throw new RuntimeException($f['label'] . ' must be a number');
            $up->execute([$sid, $f['id'], $v]);
        }
        $con->prepare("UPDATE admitted_students SET status='submitted', reject_reason=NULL, submitted_at=NOW() WHERE id=?")->execute([$sid]);
        $con->commit();
    } catch (Throwable $e) { $con->rollBack(); throw $e; }
    return ok(['view' => student_view($con, $sid)]);
}

/* ---------- admin review ---------- */
function review_list($con, $p) {
    require_admin();
    $sql = 'SELECT s.id, s.reference_no, s.status, s.submitted_at, y.name year_name FROM admitted_students s JOIN academic_years y ON y.id=s.year_id WHERE 1=1';
    $args = [];
    if (!empty($p['year_id'])) { $sql .= ' AND s.year_id=?'; $args[] = (int)$p['year_id']; }
    $status = $p['status'] ?? 'submitted';
    if ($status !== 'all') { $sql .= ' AND s.status=?'; $args[] = $status; }
    $st = $con->prepare($sql . ' ORDER BY s.submitted_at DESC, s.id DESC LIMIT 300');
    $st->execute($args);
    return ok(['students' => $st->fetchAll(), 'years' => list_years($con)]);
}
function review_detail($con, $p) {
    require_admin();
    return ok(['view' => student_view($con, (int)$p['student_id'])]);
}
function set_decision($con, $p) {
    require_admin();
    $d = $p['decision'] ?? '';
    $reason = trim($p['reason'] ?? '');
    if (!in_array($d, ['approved', 'rejected'], true)) throw new RuntimeException('Invalid decision');
    if ($d === 'rejected' && $reason === '') throw new RuntimeException('Give a reason so the student knows what to fix');
    $con->prepare("UPDATE admitted_students SET status=?, reject_reason=?, decided_at=NOW() WHERE id=? AND status IN ('submitted','approved','rejected')")
        ->execute([$d, $d === 'rejected' ? $reason : null, (int)$p['student_id']]);
    return ok(['view' => student_view($con, (int)$p['student_id'])]) + review_list($con, $p);
}

/* ---------- open registration + branding settings ---------- */
function toggle_open_reg($con, $p) {
    require_super();
    $con->prepare('UPDATE academic_years SET open_registration=1-open_registration WHERE id=?')->execute([(int)$p['year_id']]);
    return ok(['years' => list_years($con), 'year' => get_year($con, $p['year_id'])]);
}
function setting_defaults() {
    return ['college_name' => 'SDA College of Education', 'college_location' => 'Asokore, Koforidua', 'tagline' => 'Online Admission Portal',
            'primary_color' => '#696cff', 'dark_sidebar' => '0', 'student_id_label' => 'Admission number',
            'student_welcome' => 'Enter your admission number to check or complete your admission.'];
}
function get_settings($con) {
    $s = setting_defaults();
    try { foreach ($con->query('SELECT skey, svalue FROM settings') as $r) $s[$r['skey']] = $r['svalue']; } catch (Throwable $e) {}
    return $s;
}
function save_settings($con, $p) {
    require_super();
    $up = $con->prepare('INSERT INTO settings(skey, svalue) VALUES(?,?) ON DUPLICATE KEY UPDATE svalue=VALUES(svalue)');
    foreach (array_keys(setting_defaults()) as $k) {
        if (!isset($p[$k])) continue;
        $v = trim($p[$k]);
        if ($k === 'primary_color' && !preg_match('/^#[0-9a-fA-F]{6}$/', $v)) throw new RuntimeException('Pick a valid colour');
        if ($k === 'college_name' && $v === '') throw new RuntimeException('College name is required');
        $up->execute([$k, mb_substr($v, 0, 300)]);
    }
    if (!empty($p['logo_b64'])) {
        $bin = base64_decode($p['logo_b64'], true);
        if ($bin === false || strlen($bin) > 1024 * 1024 || substr($bin, 0, 8) !== "\x89PNG\r\n\x1a\n") throw new RuntimeException('Logo must be a PNG under 1MB');
        file_put_contents(__DIR__ . '/logo.png', $bin);
    }
    return ok(['settings' => get_settings($con), 'logo_version' => time()]);
}

function search_students($con, $p) {
    require_admin();
    $q = trim($p['q'] ?? '');
    if ($q === '') return ok(['results' => []]);
    $st = $con->prepare('SELECT s.id, s.reference_no, s.status, y.name year_name FROM admitted_students s JOIN academic_years y ON y.id=s.year_id WHERE s.reference_no LIKE ? ORDER BY s.id DESC LIMIT 8');
    $st->execute(['%' . $q . '%']);
    return ok(['results' => $st->fetchAll()]);
}

/* ---------- users (super admin only) ---------- */
function list_users($con) {
    require_super();
    $u = $con->query("SELECT id, full_name, username, role, is_active FROM admins ORDER BY role='super' DESC, id")->fetchAll();
    return ok(['users' => $u, 'me' => (int)$_SESSION['admin_id']]);
}
function create_user($con, $p) {
    require_super();
    $name = trim($p['full_name'] ?? '');
    $user = trim($p['username'] ?? '');
    $role = $p['role'] ?? 'admin';
    if ($name === '') throw new RuntimeException('Enter the full name');
    if (!preg_match('/^[A-Za-z0-9_.-]{3,40}$/', $user)) throw new RuntimeException('Username: 3 to 40 letters, numbers, . _ -');
    if (strlen($p['password'] ?? '') < 8) throw new RuntimeException('Password must be at least 8 characters');
    if (!in_array($role, ['super', 'admin'], true)) throw new RuntimeException('Invalid role');
    $ex = $con->prepare('SELECT COUNT(*) FROM admins WHERE username=?');
    $ex->execute([$user]);
    if ($ex->fetchColumn()) throw new RuntimeException('That username is already taken');
    $con->prepare('INSERT INTO admins(full_name, username, password_hash, role) VALUES(?,?,?,?)')
        ->execute([$name, $user, password_hash($p['password'], PASSWORD_DEFAULT), $role]);
    return list_users($con);
}
function toggle_user($con, $p) {
    require_super();
    if ((int)$p['user_id'] === (int)$_SESSION['admin_id']) throw new RuntimeException('You cannot disable your own account');
    $con->prepare('UPDATE admins SET is_active=1-is_active WHERE id=?')->execute([(int)$p['user_id']]);
    return list_users($con);
}
function reset_user_password($con, $p) {
    require_super();
    if (strlen($p['password'] ?? '') < 8) throw new RuntimeException('Password must be at least 8 characters');
    $con->prepare('UPDATE admins SET password_hash=? WHERE id=?')->execute([password_hash($p['password'], PASSWORD_DEFAULT), (int)$p['user_id']]);
    return list_users($con);
}
function delete_user($con, $p) {
    require_super();
    if ((int)$p['user_id'] === (int)$_SESSION['admin_id']) throw new RuntimeException('You cannot delete your own account');
    $con->prepare('DELETE FROM admins WHERE id=?')->execute([(int)$p['user_id']]);
    return list_users($con);
}

function reorder_fields($con, $p) {
    require_super();
    $yid = (int)$p['year_id'];
    $ids = array_map('intval', json_decode($p['order'] ?? '[]', true) ?: []);
    $have = array_map('intval', array_column(list_fields($con, $yid), 'id'));
    if (!$ids || count(array_unique($ids)) !== count($have) || array_diff($ids, $have)) throw new RuntimeException('The list changed. Refresh the page and try again');
    $con->beginTransaction();
    try {
        $u = $con->prepare('UPDATE year_fields SET sort_order=? WHERE id=? AND year_id=?');
        foreach ($ids as $i => $id) $u->execute([$i + 1, $id, $yid]);
        $con->commit();
    } catch (Throwable $e) { $con->rollBack(); throw $e; }
    return ok(['fields' => list_fields($con, $yid)]);
}

/* ---------- delete pending students (super admin only) ---------- */
function list_pending($con, $p) {
    require_super();
    $st = $con->prepare("SELECT id, reference_no FROM admitted_students WHERE year_id=? AND status='pending' ORDER BY id");
    $st->execute([(int)$p['year_id']]);
    return ok(['students' => $st->fetchAll()]);
}
function delete_student($con, $p) {
    require_super();
    $yid = (int)$p['year_id'];
    $st = $con->prepare("DELETE FROM admitted_students WHERE id=? AND year_id=? AND status='pending'");
    $st->execute([(int)$p['student_id'], $yid]);
    if (!$st->rowCount()) throw new RuntimeException('Only students who have not submitted can be deleted');
    return ok(['deleted' => 1]) + list_students($con, ['year_id' => $yid, 'q' => $p['q'] ?? '', 'status' => $p['status'] ?? '']);
}
function delete_students_bulk($con, $p) {
    require_super();
    $yid = (int)$p['year_id'];
    $ids = array_values(array_unique(array_map('intval', json_decode($p['ids'] ?? '[]', true) ?: [])));
    if (!$ids) throw new RuntimeException('Select at least one student');
    $deleted = 0;
    $con->beginTransaction();
    try {
        foreach (array_chunk($ids, 500) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            $st = $con->prepare("DELETE FROM admitted_students WHERE year_id=? AND status='pending' AND id IN ($in)");
            $st->execute(array_merge([$yid], $chunk));
            $deleted += $st->rowCount();
        }
        $con->commit();
    } catch (Throwable $e) { $con->rollBack(); throw $e; }
    return ok(['deleted' => $deleted, 'skipped' => count($ids) - $deleted, 'pending' => list_pending($con, ['year_id' => $yid])['students']])
        + list_students($con, ['year_id' => $yid, 'q' => $p['q'] ?? '', 'status' => $p['status'] ?? '']);
}

function field_options($type, $raw) {
    if ($type !== 'select') return null;
    $list = array_values(array_unique(array_filter(array_map('trim', preg_split('/[\r\n,]+/', $raw)), 'strlen')));
    if (count($list) < 2) throw new RuntimeException('Add at least two choices, one per line');
    return json_encode($list, JSON_UNESCAPED_UNICODE);
}
function edit_field($con, $p) {
    require_super();
    $fid = (int)$p['field_id'];
    $yid = (int)$p['year_id'];
    $cur = $con->prepare('SELECT * FROM year_fields WHERE id=? AND year_id=?');
    $cur->execute([$fid, $yid]);
    $cur = $cur->fetch();
    if (!$cur) throw new RuntimeException('Field not found');
    $label = trim($p['label'] ?? '');
    $type = $p['type'] ?? $cur['type'];
    if ($label === '' || !in_array($type, ['text', 'textarea', 'email', 'tel', 'date', 'number', 'file', 'select'], true)) throw new RuntimeException('Give the field a name and a valid type');
    if ($type !== $cur['type']) {
        $n = $con->prepare("SELECT COUNT(*) FROM student_values WHERE field_id=? AND value<>''");
        $n->execute([$fid]);
        if ($n->fetchColumn()) throw new RuntimeException('Students already answered this field, so its type cannot change. Remove it and add a new one instead');
    }
    $opts = field_options($type, $p['options'] ?? '');
    $con->prepare('UPDATE year_fields SET label=?, type=?, options=?, is_required=?, allow_update=? WHERE id=?')
        ->execute([$label, $type, $opts, empty($p['is_required']) ? 0 : 1, empty($p['allow_update']) ? 0 : 1, $fid]);
    return ok(['fields' => list_fields($con, $yid)]);
}