const API = 'server_controller.php';
const esc = s => $('<div>').text(s ?? '').html();
const BADGE = {pending:'secondary',submitted:'warning',approved:'success',rejected:'danger',open:'success',closed:'secondary'};
const badge = s => `<span class="badge bg-label-${BADGE[s] || 'secondary'} text-capitalize">${esc(s)}</span>`;

function toast(msg, type = 'success') {
  if (!$('#toasts').length) $('body').append('<div id="toasts" class="toast-container position-fixed top-0 end-0 p-3" style="z-index:2000"></div>');
  const el = $(`<div class="toast align-items-center text-bg-${type} border-0"><div class="d-flex"><div class="toast-body">${esc(msg)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div>`);
  $('#toasts').append(el);
  const t = new bootstrap.Toast(el[0], {delay: 3500}); t.show();
  el.on('hidden.bs.toast', () => el.remove());
}

// every request: {flag: true, ...data}; resolves only on status === 'success'
function api(payload) {
  return new Promise((resolve, reject) => {
    $.ajax({url: API, method: 'POST', data: payload, dataType: 'json'})
      .done(r => r.status === 'success' ? resolve(r) : (toast(r.message || 'Something went wrong', 'danger'), reject(r)))
      .fail(() => { toast('Server error. Try again', 'danger'); reject(); });
  });
}
const fileToB64 = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.onerror = rej; r.readAsDataURL(f); });
function downloadB64(b64, filename) {
  const bin = atob(b64), arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([arr])); a.download = filename; a.click(); URL.revokeObjectURL(a.href);
}
// read-only detail cards for a student view (admin review + student page)
function detailCards(fields) {
  return fields.map(f => {
    let v = f.value ? esc(f.value) : '<span class="text-muted">Not provided</span>';
    if (f.type === 'file' && f.value) v = /\.pdf$/i.test(f.value) ? `<a href="${esc(f.value)}" target="_blank"><i class="bx bx-file"></i> Open document</a>` : `<a href="${esc(f.value)}" target="_blank"><img class="photo" src="${esc(f.value)}"></a>`;
    return `<div class="col-md-6"><div class="card h-100"><div class="card-body"><small class="text-muted d-block mb-1">${esc(f.label)}</small><div class="fw-medium text-break">${v}</div></div></div></div>`;
  }).join('');
}
