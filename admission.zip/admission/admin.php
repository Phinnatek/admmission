<?php
require_once 'config.php';
require_once 'layout.php';
if (empty($_SESSION['admin_id'])):
    $S = get_settings($con);
    brand_head($S, 'Admin login'); ?>
<body><div class="auth-wrap"><div class="card auth-card">
  <div class="auth-logo"><img src="logo.png" alt="logo"><span class="t"><?= htmlspecialchars($S['college_name']) ?></span><span class="s"><?= htmlspecialchars($S['college_location']) ?></span></div>
  <h5 class="mb-1">Welcome to the admissions office</h5><p class="mb-4">Sign in to manage this year's admissions</p>
  <div class="mb-3"><label class="form-label">Username</label><input id="u" class="form-control" autofocus></div>
  <div class="mb-4"><label class="form-label">Password</label><input id="p" type="password" class="form-control"></div>
  <button id="go" class="btn btn-primary w-100">Sign in</button>
</div></div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/app.js"></script>
<script>
const login = () => api({admin_login: true, username: $('#u').val(), password: $('#p').val()}).then(() => location.reload());
$('#go').on('click', login); $('#p').on('keydown', e => { if (e.key === 'Enter') login(); });
</script></body></html>
<?php exit; endif;
$S = get_settings($con);
$isSuper = ($_SESSION['admin_role'] ?? '') === 'super';
layout_top('Academic Years', 'years'); ?>
<div class="row g-4 mb-4">
  <div class="<?= $isSuper ? 'col-lg-8' : 'col-12' ?>"><div class="card h-100"><div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div style="max-width:430px"><h5 class="text-primary mb-2">Welcome to <?= htmlspecialchars($S['college_name']) ?> admissions</h5>
    <p class="mb-3">Create an academic year, load admitted students, choose which details to collect, then approve what they submit.</p>
    <a href="review.php" class="btn btn-sm btn-outline-primary">Review submissions</a></div>
    <i class="bx bxs-graduation text-primary" style="font-size:6rem;opacity:.85"></i>
  </div></div></div>
<?php if ($isSuper): ?>
  <div class="col-lg-4"><div class="card h-100"><div class="card-body">
    <h6 class="mb-3">New academic year</h6>
    <input id="yname" class="form-control mb-3" placeholder="e.g. 2026/2027">
    <button id="addYear" class="btn btn-primary w-100"><i class="bx bx-plus"></i> Create year</button>
  </div></div></div>
<?php endif; ?>
</div>
<div id="totals" class="row g-4 mb-4"></div>
<h5 class="mb-3">Academic years</h5>
<div id="years" class="row g-4"></div>
<?php layout_bottom(); ?>
<script>
const IS_SUPER = <?= $isSuper ? 'true' : 'false' ?>;
const tot = (icon, color, label, v) => `<div class="col-6 col-xl-3"><div class="card"><div class="card-body"><div class="d-flex justify-content-between align-items-start mb-3"><span class="avatar-init bg-label-${color}"><i class="bx ${icon}"></i></span></div><span class="text-muted d-block mb-1">${label}</span><h4 class="mb-0">${v}</h4></div></div></div>`;
const yearCard = y => `<div class="col-md-6 col-xl-4"><div class="card h-100"><div class="card-body">
  <div class="d-flex justify-content-between align-items-start mb-3">
    <div class="d-flex gap-3"><span class="avatar-init bg-label-primary"><i class="bx bx-calendar"></i></span><div><h5 class="mb-1">${esc(y.name)}</h5>${badge(y.status)} ${+y.open_registration ? '<span class="badge bg-label-info">Open registration</span>' : ''}</div></div>
    ${IS_SUPER ? `<button class="btn btn-sm btn-outline-secondary toggle" data-id="${y.id}">${y.status === 'open' ? 'Close' : 'Reopen'}</button>` : ''}
  </div>
  <div class="row text-center mb-4">
    <div class="col"><h5 class="mb-0">${y.total}</h5><small>Admitted</small></div>
    <div class="col"><h5 class="mb-0">${y.submitted}</h5><small>To review</small></div>
    <div class="col"><h5 class="mb-0">${y.approved}</h5><small>Approved</small></div>
  </div>
  ${IS_SUPER ? `<a href="manage.php?year=${y.id}" target="_blank" class="btn btn-primary w-100"><i class="bx bx-cog"></i> Manage</a>` : `<a href="review.php?year=${y.id}" class="btn btn-primary w-100"><i class="bx bx-check-shield"></i> Review submissions</a>`}
</div></div></div>`;
function render(ys) {
  const sum = k => ys.reduce((a, y) => a + (+y[k]), 0);
  $('#totals').html(tot('bx-calendar', 'primary', 'Academic years', ys.length) + tot('bx-group', 'info', 'Admitted students', sum('total')) + tot('bx-time-five', 'warning', 'Awaiting review', sum('submitted')) + tot('bx-check-circle', 'success', 'Approved', sum('approved')));
  $('#years').html(ys.length ? ys.map(yearCard).join('') : '<div class="col-12"><div class="card"><div class="card-body text-center py-5">Create your first academic year to start loading admitted students.</div></div></div>');
}
api({list_years: true}).then(r => render(r.years));
$('#addYear').on('click', () => api({create_year: true, name: $('#yname').val()}).then(r => { render(r.years); $('#yname').val(''); toast('Academic year created'); }));
$('#years').on('click', '.toggle', function () { api({toggle_year: true, year_id: $(this).data('id')}).then(r => { render(r.years); toast('Year updated'); }); });
</script></body></html>